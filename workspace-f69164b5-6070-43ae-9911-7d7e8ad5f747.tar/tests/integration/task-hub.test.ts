/**
 * Integration Tests for Earnify Task Hub
 * These tests verify the complete workflow from claim to reward
 */

const BASE_URL = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'

// Test configuration
const testConfig = {
  timeout: 30000,
  retries: 3,
  retryDelay: 1000
}

// Helper functions
async function makeRequest(endpoint: string, options: RequestInit = {}) {
  const response = await fetch(`${BASE_URL}${endpoint}`, {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers
    },
    ...options
  })
  
  const data = await response.json()
  return { response, data }
}

async function createTestUser() {
  // This would typically create a test user via auth
  // For now, we'll use a mock user ID
  return {
    id: 'test-user-' + Math.random().toString(36).substr(2, 9),
    phone: '+1234567890',
    displayName: 'Test User'
  }
}

// Test Suite
describe('Earnify Task Hub Integration Tests', () => {
  let testUser: any
  let testTask: any
  let authToken: string

  beforeAll(async () => {
    // Setup test environment
    console.log('Setting up test environment...')
    
    // Create test user
    testUser = await createTestUser()
    
    // Create a test task
    const { data: taskData } = await makeRequest('/api/tasks', {
      method: 'POST',
      body: JSON.stringify({
        title: 'Test Integration Task',
        description: 'Task for integration testing',
        task_type: 'typing',
        reward_points: 10,
        active: true
      })
    })
    
    testTask = taskData.task
    console.log('Test environment setup complete')
  })

  afterAll(async () => {
    // Cleanup test environment
    console.log('Cleaning up test environment...')
    // Delete test data here
  })

  describe('Task Claim Workflow', () => {
    test('should prevent duplicate claims', async () => {
      // First claim should succeed
      const { response: firstResponse, data: firstData } = await makeRequest('/api/claim-task', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          taskId: testTask.id
        })
      })

      expect(firstResponse.status).toBe(200)
      expect(firstData.success).toBe(true)
      expect(firstData.submission.status).toBe('claimed')

      // Second claim should fail
      const { response: secondResponse, data: secondData } = await makeRequest('/api/claim-task', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          taskId: testTask.id
        })
      })

      expect(secondResponse.status).toBe(409)
      expect(secondData.error).toContain('already claimed')
    })

    test('should create task_submission with status=claimed', async () => {
      const { response, data } = await makeRequest('/api/claim-task', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          taskId: testTask.id
        })
      })

      expect(response.status).toBe(200)
      expect(data.success).toBe(true)
      expect(data.submission.status).toBe('claimed')
      expect(data.submission.task_id).toBe(testTask.id)
      expect(data.submission.user_id).toBe(testUser.id)
    })
  })

  describe('Task Submission Workflow', () => {
    let claimedSubmission: any

    beforeEach(async () => {
      // Claim a task for submission tests
      const { data } = await makeRequest('/api/claim-task', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          taskId: testTask.id
        })
      })
      claimedSubmission = data.submission
    })

    test('should auto-approve text tasks with similarity >= 90%', async () => {
      const submissionText = 'The quick brown fox jumps over the lazy dog'
      const similarityScore = 0.95 // 95% similarity

      const { response, data } = await makeRequest('/api/submit-task', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          taskId: testTask.id,
          submissionText,
          similarityScore
        })
      })

      expect(response.status).toBe(200)
      expect(data.success).toBe(true)
      expect(data.submission.status).toBe('approved')
      expect(data.submission.pointsAwarded).toBe(testTask.reward_points)
    })

    test('should reject text tasks with similarity < 90%', async () => {
      const submissionText = 'Completely different text'
      const similarityScore = 0.3 // 30% similarity

      const { response, data } = await makeRequest('/api/submit-task', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          taskId: testTask.id,
          submissionText,
          similarityScore
        })
      })

      expect(response.status).toBe(200)
      expect(data.success).toBe(true)
      expect(data.submission.status).toBe('rejected')
      expect(data.submission.pointsAwarded).toBe(0)
    })

    test('should handle transcription submissions', async () => {
      const { response, data } = await makeRequest('/api/submit-task', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          taskId: testTask.id,
          submissionUrl: 'https://example.com/audio.mp3'
        })
      })

      expect(response.status).toBe(200)
      expect(data.success).toBe(true)
      expect(data.submission.status).toBe('pending') // Transcription tasks need manual review
    })
  })

  describe('Audio Upload Workflow', () => {
    test('should upload audio files to Supabase Storage', async () => {
      // Create a mock audio file
      const audioFile = new Blob(['mock audio data'], { type: 'audio/mpeg' })
      const formData = new FormData()
      formData.append('file', audioFile, 'test-audio.mp3')
      formData.append('taskId', testTask.id)

      const { response, data } = await makeRequest('/api/upload-audio', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: formData
      })

      expect(response.status).toBe(200)
      expect(data.success).toBe(true)
      expect(data.fileUrl).toBeDefined()
      expect(data.verificationJob).toBeDefined()
    })

    test('should reject invalid file types', async () => {
      const textFile = new Blob(['mock text data'], { type: 'text/plain' })
      const formData = new FormData()
      formData.append('file', textFile, 'test.txt')
      formData.append('taskId', testTask.id)

      const { response, data } = await makeRequest('/api/upload-audio', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: formData
      })

      expect(response.status).toBe(400)
      expect(data.error).toContain('Invalid file type')
    })
  })

  describe('Points Awarding System', () => {
    test('should award points atomically', async () => {
      const pointsToAward = 50

      const { response, data } = await makeRequest('/api/award-points', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          userId: testUser.id,
          points: pointsToAward,
          kind: 'bonus',
          metadata: { reason: 'Test award' }
        })
      })

      expect(response.status).toBe(200)
      expect(data.success).toBe(true)
      expect(data.pointsAwarded).toBe(pointsToAward)

      // Verify transaction was created
      const { data: transactions } = await makeRequest(`/api/user/transactions?userId=${testUser.id}`)
      expect(transactions).toContainEqual(
        expect.objectContaining({
          points: pointsToAward,
          kind: 'bonus'
        })
      )
    })

    test('should update user profile balance', async () => {
      const initialBalance = 100
      const pointsToAward = 25

      // Set initial balance
      await makeRequest('/api/award-points', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          userId: testUser.id,
          points: initialBalance,
          kind: 'adjustment'
        })
      })

      // Award additional points
      const { response, data } = await makeRequest('/api/award-points', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          userId: testUser.id,
          points: pointsToAward,
          kind: 'bonus'
        })
      })

      expect(response.status).toBe(200)

      // Check final balance
      const { data: profile } = await makeRequest(`/api/user/profile?userId=${testUser.id}`)
      expect(profile.total_points).toBe(initialBalance + pointsToAward)
    })
  })

  describe('Admin Management', () => {
    let adminToken: string

    beforeAll(async () => {
      // Get admin token (this would be set up in test environment)
      adminToken = process.env.TEST_ADMIN_TOKEN || 'mock-admin-token'
    })

    test('should allow admin to approve pending submissions', async () => {
      // Create a pending submission first
      const { data: submission } = await makeRequest('/api/claim-task', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          taskId: testTask.id
        })
      })

      // Admin approves the submission
      const { response, data } = await makeRequest('/api/admin/approve-submission', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${adminToken}`
        },
        body: JSON.stringify({
          submissionId: submission.submission.id
        })
      })

      expect(response.status).toBe(200)
      expect(data.success).toBe(true)
      expect(data.submission.status).toBe('approved')
      expect(data.submission.pointsAwarded).toBeGreaterThan(0)
    })

    test('should allow admin to reject pending submissions', async () => {
      // Create a pending submission first
      const { data: submission } = await makeRequest('/api/claim-task', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          taskId: testTask.id
        })
      })

      const rejectionReason = 'Test rejection reason'

      // Admin rejects the submission
      const { response, data } = await makeRequest('/api/admin/reject-submission', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${adminToken}`
        },
        body: JSON.stringify({
          submissionId: submission.submission.id,
          reason: rejectionReason
        })
      })

      expect(response.status).toBe(200)
      expect(data.success).toBe(true)
      expect(data.submission.status).toBe('rejected')
      expect(data.submission.rejectionReason).toBe(rejectionReason)
    })

    test('should verify transcription with similarity >= 90%', async () => {
      // Create a transcription submission
      const { data: submission } = await makeRequest('/api/submit-task', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          taskId: testTask.id,
          submissionUrl: 'https://example.com/audio.mp3'
        })
      })

      const similarityScore = 0.92

      // Admin verifies transcription
      const { response, data } = await makeRequest('/api/verify-transcription', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${adminToken}`
        },
        body: JSON.stringify({
          submissionId: submission.submission.id,
          similarityScore
        })
      })

      expect(response.status).toBe(200)
      expect(data.success).toBe(true)
      expect(data.submission.approved).toBe(true)
      expect(data.submission.pointsAwarded).toBeGreaterThan(0)
    })
  })

  describe('Error Handling', () => {
    test('should handle invalid task IDs gracefully', async () => {
      const { response, data } = await makeRequest('/api/claim-task', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          taskId: 'invalid-task-id'
        })
      })

      expect(response.status).toBe(404)
      expect(data.error).toContain('not found')
    })

    test('should handle missing authentication', async () => {
      const { response, data } = await makeRequest('/api/claim-task', {
        method: 'POST',
        body: JSON.stringify({
          taskId: testTask.id
        })
      })

      expect(response.status).toBe(401)
      expect(data.error).toContain('Authentication required')
    })

    test('should handle rate limiting', async () => {
      // Make multiple rapid requests
      const requests = Array(10).fill(null).map(() =>
        makeRequest('/api/claim-task', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${authToken}`
          },
          body: JSON.stringify({
            taskId: testTask.id
          })
        })
      )

      const responses = await Promise.all(requests)
      
      // At least some requests should be rate limited
      const rateLimitedResponses = responses.filter(({ response }) => response.status === 429)
      expect(rateLimitedResponses.length).toBeGreaterThan(0)
    })
  })

  describe('Performance Tests', () => {
    test('should handle concurrent claims', async () => {
      const concurrentRequests = 20
      const requests = Array(concurrentRequests).fill(null).map((_, index) =>
        makeRequest('/api/claim-task', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${authToken}`
          },
          body: JSON.stringify({
            taskId: `${testTask.id}-${index}` // Different task IDs
          })
        })
      )

      const startTime = Date.now()
      const responses = await Promise.all(requests)
      const endTime = Date.now()

      const totalTime = endTime - startTime
      const averageTime = totalTime / concurrentRequests

      // Should handle concurrent requests efficiently
      expect(averageTime).toBeLessThan(1000) // Less than 1 second per request
      expect(totalTime).toBeLessThan(5000) // Less than 5 seconds total

      // All requests should succeed
      const successfulResponses = responses.filter(({ response }) => response.status === 200)
      expect(successfulResponses.length).toBe(concurrentRequests)
    })
  })
})

// Export for use in test runners
export { testConfig, makeRequest, createTestUser }