"use client"

import { createContext, useContext, useEffect, useState } from 'react'
import { User, Session, AuthError } from '@supabase/supabase-js'
import { supabase } from '@/lib/supabaseClient'

interface AuthContextType {
  user: User | null
  session: Session | null
  loading: boolean
  signInWithPhone: (phone: string) => Promise<{ error: AuthError | null }>
  verifyOTP: (phone: string, token: string, displayName?: string, referralCode?: string, upiId?: string) => Promise<{ error: AuthError | null }>
  signOut: () => Promise<{ error: AuthError | null }>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Get initial session
    const getInitialSession = async () => {
      const { data: { session } } = await supabase.auth.getSession()
      setSession(session)
      setUser(session?.user ?? null)
      setLoading(false)
    }

    getInitialSession()

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session)
        setUser(session?.user ?? null)
        setLoading(false)

        // Handle user creation/update after sign in
        if (event === 'SIGNED_IN' && session?.user) {
          await handleUserSignIn(session.user)
        }
      }
    )

    return () => subscription.unsubscribe()
  }, [])

  const handleUserSignIn = async (user: User) => {
    // Check if profile exists, create if not
    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single()

    if (!profile) {
      // Profile will be created automatically by the database trigger
      console.log('Profile will be created by trigger for user:', user.id)
    } else {
      // Update daily login streak and award bonus
      try {
        const { data: bonusPoints } = await supabase.rpc('update_daily_streak_and_bonus', {
          p_user_id: user.id
        })
        
        if (bonusPoints && bonusPoints > 0) {
          console.log(`Daily login bonus awarded: ${bonusPoints} points`)
        }
      } catch (error) {
        console.error('Failed to update daily streak:', error)
      }
    }
  }

  const signInWithPhone = async (phone: string) => {
    const { error } = await supabase.auth.signInWithOtp({
      phone,
      options: {
        shouldCreateUser: true,
      }
    })
    return { error }
  }

  const verifyOTP = async (phone: string, token: string, displayName?: string, referralCode?: string, upiId?: string) => {
    const { error } = await supabase.auth.verifyOtp({
      phone,
      token,
      type: 'sms'
    })

    if (!error) {
      // Update profile with additional info if provided
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        const updates: any = {}
        if (displayName) updates.display_name = displayName
        if (upiId) updates.upi_id = upiId

        // Handle referral code
        if (referralCode) {
          const { data: referrer } = await supabase
            .from('profiles')
            .select('id')
            .eq('referral_code', referralCode)
            .single()

          if (referrer) {
            updates.referred_by = referrer.id
          }
        }

        if (Object.keys(updates).length > 0) {
          await supabase
            .from('profiles')
            .update(updates)
            .eq('id', user.id)
        }
      }
    }

    return { error }
  }

  const signOut = async () => {
    const { error } = await supabase.auth.signOut()
    return { error }
  }

  const value = {
    user,
    session,
    loading,
    signInWithPhone,
    verifyOTP,
    signOut,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}