'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  Flame, 
  Star, 
  Trophy, 
  Award, 
  Crown, 
  Gem,
  Calendar,
  Target,
  Zap
} from 'lucide-react'

interface GamificationStats {
  streak_count: number
  last_login_date: string
  current_level: number
  total_tasks_completed: number
  total_earned_points: number
  badges: Array<{
    badge_type: string
    badge_name: string
    badge_description: string
    badge_icon: string
    earned_at: string
  }>
}

interface UserBadge {
  id: string
  badge_type: string
  badge_name: string
  badge_description: string
  badge_icon: string
  earned_at: string
}

export default function GamificationPanel() {
  const [stats, setStats] = useState<GamificationStats | null>(null)
  const [badges, setBadges] = useState<UserBadge[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchGamificationData()
  }, [])

  const fetchGamificationData = async () => {
    try {
      const [statsResponse, badgesResponse] = await Promise.all([
        fetch('/api/gamification/stats'),
        fetch('/api/gamification/badges')
      ])

      if (statsResponse.ok) {
        const statsData = await statsResponse.json()
        setStats(statsData.stats)
      }

      if (badgesResponse.ok) {
        const badgesData = await badgesResponse.json()
        setBadges(badgesData.badges)
      }
    } catch (error) {
      console.error('Failed to fetch gamification data:', error)
    } finally {
      setLoading(false)
    }
  }

  const getBadgeIcon = (badgeType: string) => {
    const iconMap: { [key: string]: React.ReactNode } = {
      'newbie': <Award className="h-4 w-4" />,
      'regular': <Star className="h-4 w-4" />,
      'achiever': <Trophy className="h-4 w-4" />,
      'master': <Crown className="h-4 w-4" />,
      'legend': <Gem className="h-4 w-4" />
    }
    return iconMap[badgeType] || <Award className="h-4 w-4" />
  }

  const getBadgeColor = (badgeType: string) => {
    const colorMap: { [key: string]: string } = {
      'newbie': 'bg-green-100 text-green-800',
      'regular': 'bg-blue-100 text-blue-800',
      'achiever': 'bg-purple-100 text-purple-800',
      'master': 'bg-orange-100 text-orange-800',
      'legend': 'bg-red-100 text-red-800'
    }
    return colorMap[badgeType] || 'bg-gray-100 text-gray-800'
  }

  const getLevelProgress = () => {
    if (!stats) return 0
    const tasksForNextLevel = stats.current_level * 20
    const currentTasks = stats.total_tasks_completed
    const tasksInCurrentLevel = currentTasks % 20
    return (tasksInCurrentLevel / 20) * 100
  }

  const getStreakColor = () => {
    if (!stats) return 'text-gray-600'
    if (stats.streak_count >= 30) return 'text-red-600'
    if (stats.streak_count >= 14) return 'text-orange-600'
    if (stats.streak_count >= 7) return 'text-yellow-600'
    return 'text-green-600'
  }

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-4 bg-gray-200 rounded mb-4 w-20"></div>
              <div className="h-8 bg-gray-200 rounded mb-2"></div>
              <div className="h-4 bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Streak Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Daily Streak</CardTitle>
            <Flame className={`h-4 w-4 ${getStreakColor()}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.streak_count || 0}</div>
            <p className="text-xs text-muted-foreground">
              {stats?.last_login_date ? `Last login: ${new Date(stats.last_login_date).toLocaleDateString()}` : 'No login yet'}
            </p>
          </CardContent>
        </Card>

        {/* Level Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Level</CardTitle>
            <Target className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.current_level || 1}</div>
            <Progress value={getLevelProgress()} className="mt-2" />
            <p className="text-xs text-muted-foreground mt-2">
              {stats?.total_tasks_completed || 0} tasks completed
            </p>
          </CardContent>
        </Card>

        {/* Points Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Earned</CardTitle>
            <Zap className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.total_earned_points || 0}</div>
            <p className="text-xs text-muted-foreground">
              Points from tasks & bonuses
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Badges Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5" />
            Your Badges
          </CardTitle>
        </CardHeader>
        <CardContent>
          {badges.length === 0 ? (
            <div className="text-center py-8">
              <Award className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Badges Yet</h3>
              <p className="text-muted-foreground">
                Complete tasks to earn your first badges!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {badges.map((badge) => (
                <div
                  key={badge.id}
                  className="text-center p-4 border rounded-lg hover:shadow-md transition-shadow"
                >
                  <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full mb-2 ${getBadgeColor(badge.badge_type)}`}>
                    {getBadgeIcon(badge.badge_type)}
                  </div>
                  <h4 className="font-semibold text-sm">{badge.badge_name}</h4>
                  <p className="text-xs text-muted-foreground mt-1">
                    {new Date(badge.earned_at).toLocaleDateString()}
                  </p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Level Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Level Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Level {stats?.current_level || 1}</span>
                <span className="text-sm text-muted-foreground">
                  {stats?.total_tasks_completed || 0} / {((stats?.current_level || 1) * 20)} tasks
                </span>
              </div>
              <Progress value={getLevelProgress()} />
            </div>
            <div className="text-sm text-muted-foreground">
              <p>Complete {20 - ((stats?.total_tasks_completed || 0) % 20)} more tasks to reach Level {(stats?.current_level || 1) + 1}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}