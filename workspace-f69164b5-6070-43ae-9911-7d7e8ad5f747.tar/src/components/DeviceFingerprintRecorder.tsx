'use client'

import { useEffect } from 'react'
import { DeviceFingerprint } from '@/lib/device-fingerprint'
import { useAuth } from '@/components/AuthProvider'

export function DeviceFingerprintRecorder() {
  const { user } = useAuth()

  useEffect(() => {
    if (user) {
      const recordFingerprint = async () => {
        try {
          const fingerprint = DeviceFingerprint.generate()
          
          const response = await fetch('/api/auth/fingerprint', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ fingerprint }),
          })

          if (!response.ok) {
            console.error('Failed to record device fingerprint')
          }
        } catch (error) {
          console.error('Error recording device fingerprint:', error)
        }
      }

      // Record fingerprint when user logs in
      recordFingerprint()

      // Also record fingerprint periodically (every 5 minutes)
      const interval = setInterval(recordFingerprint, 5 * 60 * 1000)

      return () => clearInterval(interval)
    }
  }, [user])

  return null
}