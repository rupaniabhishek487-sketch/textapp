export interface Task {
  id: string
  title: string
  description: string
  task_type: 'typing' | 'transcription' | 'survey' | 'other'
  reward_points: number
  payload_url?: string
  max_completions?: number
  active: boolean
  created_at: string
  updated_at: string
}

export interface TaskSubmission {
  id: string
  task_id: string
  user_id: string
  submission_text?: string
  submission_url?: string
  auto_score: number
  manual_score?: number
  status: 'claimed' | 'submitted' | 'approved' | 'rejected'
  reward_points: number
  claimed_at?: string
  submitted_at?: string
  reviewed_at?: string
  expires_at?: string
  created_at: string
  updated_at: string
  tasks?: Task
}

export interface Profile {
  id: string
  display_name?: string
  phone?: string
  upi_id?: string
  total_points: number
  balance_inr: number
  total_tasks_completed: number
  total_earnings_inr: number
  referral_code?: string
  referred_by?: string
  is_verified: boolean
  created_at: string
  updated_at: string
}

export interface Transaction {
  id: string
  user_id: string
  kind: 'task_reward' | 'payout' | 'refund' | 'bonus'
  points: number
  inr_value: number
  meta?: Record<string, any>
  status: 'pending' | 'completed' | 'failed'
  created_at: string
  updated_at: string
}

export interface PayoutRequest {
  id: string
  user_id: string
  amount_inr: number
  points_used: number
  status: 'pending' | 'processing' | 'completed' | 'rejected'
  upi_id: string
  notes?: string
  processed_at?: string
  created_at: string
  updated_at: string
}

export interface DeviceFingerprint {
  id: string
  user_id: string
  fingerprint_hash: string
  ip_address?: string
  user_agent?: string
  last_seen: string
  created_at: string
  is_suspicious: boolean
}

export interface RateLimit {
  id: string
  user_id: string
  action_type: string
  timestamp: string
  metadata: Record<string, any>
}

export interface FraudAlert {
  id: string
  user_id: string
  alert_type: string
  severity: 'low' | 'medium' | 'high'
  description: string
  metadata: Record<string, any>
  status: 'active' | 'resolved' | 'dismissed'
  created_at: string
  resolved_at?: string
}

export interface UserSuspension {
  id: string
  user_id: string
  reason: string
  suspended_by?: string
  suspended_at: string
  lifted_at?: string
  is_active: boolean
  notes?: string
}

export interface SuspiciousUser {
  user_id: string
  username: string
  email: string
  is_suspended: boolean
  alert_count: number
  latest_alert_type?: string
  latest_severity?: string
  device_count: number
  ip_addresses: string[]
}