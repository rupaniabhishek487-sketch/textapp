import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/components/AuthProvider";
import { DeviceFingerprintRecorder } from "@/components/DeviceFingerprintRecorder";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Earnify - Earn Rewards Online",
  description: "Join Earnify to complete tasks, earn points, and get rewarded. Simple way to make money online.",
  keywords: ["Earnify", "earn money", "rewards", "tasks", "online earning"],
  authors: [{ name: "Earnify Team" }],
  icons: {
    icon: [
      { url: "/icon-192x192.png", sizes: "192x192", type: "image/png" },
      { url: "/icon-512x512.png", sizes: "512x512", type: "image/png" }
    ],
    apple: [
      { url: "/icon-192x192.png", sizes: "192x192", type: "image/png" }
    ],
  },
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Earnify",
  },
  formatDetection: {
    telephone: false,
  },
  openGraph: {
    title: "Earnify - Earn Rewards Online",
    description: "Join Earnify to complete tasks, earn points, and get rewarded",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Earnify - Earn Rewards Online",
    description: "Join Earnify to complete tasks, earn points, and get rewarded",
  },
  other: {
    "mobile-web-app-capable": "yes",
    "apple-mobile-web-app-capable": "yes",
    "apple-mobile-web-app-status-bar-style": "default",
    "apple-mobile-web-app-title": "Earnify",
    "application-name": "Earnify",
    "msapplication-TileColor": "#10b981",
    "theme-color": "#10b981",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <AuthProvider>
          <DeviceFingerprintRecorder />
          {children}
          <Toaster />
        </AuthProvider>
      </body>
    </html>
  );
}
