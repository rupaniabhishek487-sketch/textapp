"use client"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { useAuth } from "@/components/AuthProvider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, ShieldCheck, User, Gift, CreditCard } from "lucide-react"
import { useEffect } from "react"

export default function VerifyPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [otp, setOtp] = useState("")
  const [displayName, setDisplayName] = useState("")
  const [referralCode, setReferralCode] = useState("")
  const [upiId, setUpiId] = useState("")
  const [isNewUser, setIsNewUser] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [phone, setPhone] = useState("")
  const { verifyOTP } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const phoneParam = searchParams.get("phone")
    if (phoneParam) {
      setPhone(decodeURIComponent(phoneParam))
    }
  }, [searchParams])

  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!otp || otp.length !== 6) {
      setError("Please enter a valid 6-digit OTP")
      return
    }

    if (!phone) {
      setError("Phone number not found")
      return
    }

    setIsLoading(true)
    setError("")
    setSuccess("")

    try {
      const { error } = await verifyOTP(
        phone, 
        otp, 
        isNewUser ? displayName : undefined,
        isNewUser ? referralCode : undefined,
        isNewUser ? upiId : undefined
      )
      
      if (error) {
        setError(error.message)
      } else {
        setSuccess("Verification successful!")
        setTimeout(() => {
          router.push("/dashboard")
        }, 1500)
      }
    } catch (err) {
      setError("Verification failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleResendOTP = async () => {
    // Implementation for resending OTP
    setSuccess("OTP resent successfully!")
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-emerald-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4">
            <ShieldCheck className="h-6 w-6 text-green-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-green-600">Verify Your Phone</CardTitle>
          <CardDescription>
            Enter the 6-digit OTP sent to {phone}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <form onSubmit={handleVerifyOTP} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="otp">One-Time Password</Label>
              <Input
                id="otp"
                type="text"
                placeholder="000000"
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                maxLength={6}
                className="text-center text-lg tracking-widest"
                autoFocus
              />
            </div>

            {isNewUser && (
              <div className="space-y-4 border-t pt-4">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Complete your profile</p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="displayName">
                    <User className="inline h-4 w-4 mr-1" />
                    Display Name
                  </Label>
                  <Input
                    id="displayName"
                    type="text"
                    placeholder="Enter your name"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="referralCode">
                    <Gift className="inline h-4 w-4 mr-1" />
                    Referral Code (Optional)
                  </Label>
                  <Input
                    id="referralCode"
                    type="text"
                    placeholder="Enter referral code"
                    value={referralCode}
                    onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="upiId">
                    <CreditCard className="inline h-4 w-4 mr-1" />
                    UPI ID (Optional)
                  </Label>
                  <Input
                    id="upiId"
                    type="text"
                    placeholder="yourname@upi"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                  />
                </div>
              </div>
            )}

            <Button 
              type="submit"
              disabled={isLoading || otp.length !== 6}
              className="w-full"
            >
              {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              {isNewUser ? "Create Account" : "Verify & Sign In"}
            </Button>
          </form>

          <div className="text-center space-y-2">
            <p className="text-sm text-muted-foreground">
              Didn't receive the code?
            </p>
            <Button 
              variant="outline" 
              onClick={handleResendOTP}
              disabled={isLoading}
              className="w-full"
            >
              Resend OTP
            </Button>
          </div>

          <div className="text-center">
            <Button 
              variant="ghost" 
              onClick={() => router.push("/login")}
              className="text-sm"
            >
              Back to Login
            </Button>
          </div>

          {!isNewUser && (
            <div className="text-center">
              <Button 
                variant="link" 
                onClick={() => setIsNewUser(true)}
                className="text-sm text-green-600"
              >
                First time? Create your account
              </Button>
            </div>
          )}

          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert>
              <AlertDescription>{success}</AlertDescription>
            </Alert>
          )}

          <div className="text-xs text-muted-foreground text-center border-t pt-4">
            <p>For demo: Use any 6-digit code (e.g., 123456)</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}