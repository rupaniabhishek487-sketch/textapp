"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useToast } from '@/hooks/use-toast'
import { useAuth } from '@/components/AuthProvider'
import { 
  XCircle, 
  Clock, 
  Eye, 
  Search, 
  Filter,
  TrendingUp,
  Users,
  FileText,
  AlertCircle,
  Loader2,
  Play,
  Pause,
  Wallet,
  IndianRupee,
  ArrowUpRight,
  ArrowDownRight,
  CheckIcon as CheckIcon,
  CreditCard,
  Shield,
  UserX,
  AlertTriangle
} from 'lucide-react'
import { TaskSubmission, Task, PayoutRequest, SuspiciousUser } from '@/types/supabase'

interface AdminStats {
  totalTasks: number
  activeTasks: number
  totalSubmissions: number
  pendingSubmissions: number
  approvedSubmissions: number
  rejectedSubmissions: number
}

interface PayoutStats {
  total: number
  pending: number
  processing: number
  approved: number
  paid: number
  rejected: number
}

export default function AdminDashboard() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)
  const [isAdmin, setIsAdmin] = useState(false)
  const [stats, setStats] = useState<AdminStats | null>(null)
  const [submissions, setSubmissions] = useState<TaskSubmission[]>([])
  const [filteredSubmissions, setFilteredSubmissions] = useState<TaskSubmission[]>([])
  const [payoutRequests, setPayoutRequests] = useState<PayoutRequest[]>([])
  const [filteredPayoutRequests, setFilteredPayoutRequests] = useState<PayoutRequest[]>([])
  const [payoutStats, setPayoutStats] = useState<PayoutStats | null>(null)
  const [suspiciousUsers, setSuspiciousUsers] = useState<SuspiciousUser[]>([])
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [payoutStatusFilter, setPayoutStatusFilter] = useState<string>('all')
  const [searchTerm, setSearchTerm] = useState('')
  const [payoutSearchTerm, setPayoutSearchTerm] = useState('')
  const [selectedSubmission, setSelectedSubmission] = useState<TaskSubmission | null>(null)
  const [selectedPayout, setSelectedPayout] = useState<PayoutRequest | null>(null)
  const [processingId, setProcessingId] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState('submissions')

  useEffect(() => {
    if (user) {
      checkAdminAccess()
    }
  }, [user])

  useEffect(() => {
    if (isAdmin) {
      Promise.all([
        fetchStats(),
        fetchSubmissions(),
        fetchPayoutRequests(),
        fetchSuspiciousUsers()
      ])
    }
  }, [isAdmin])

  useEffect(() => {
    filterSubmissions()
  }, [submissions, statusFilter, searchTerm])

  useEffect(() => {
    filterPayoutRequests()
  }, [payoutRequests, payoutStatusFilter, payoutSearchTerm])

  const checkAdminAccess = async () => {
    try {
      const response = await fetch('/api/admin/check-access')
      if (response.ok) {
        setIsAdmin(true)
      } else {
        window.location.href = '/dashboard'
      }
    } catch (error) {
      window.location.href = '/dashboard'
    }
  }

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/admin/stats')
      if (response.ok) {
        const data = await response.json()
        setStats(data.stats)
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error)
    }
  }

  const fetchSubmissions = async () => {
    try {
      const response = await fetch('/api/admin/submissions')
      if (response.ok) {
        const data = await response.json()
        setSubmissions(data.submissions || [])
      }
    } catch (error) {
      console.error('Failed to fetch submissions:', error)
    }
  }

  const fetchPayoutRequests = async () => {
    try {
      const response = await fetch('/api/admin/payout-requests')
      if (response.ok) {
        const data = await response.json()
        setPayoutRequests(data.requests || [])
        setPayoutStats(data.stats)
      }
    } catch (error) {
      console.error('Failed to fetch payout requests:', error)
    }
  }

  const fetchSuspiciousUsers = async () => {
    try {
      const response = await fetch('/api/admin/fraud')
      if (response.ok) {
        const data = await response.json()
        setSuspiciousUsers(data.users || [])
      }
    } catch (error) {
      console.error('Failed to fetch suspicious users:', error)
    }
  }

  const filterSubmissions = () => {
    let filtered = submissions

    if (statusFilter !== 'all') {
      filtered = filtered.filter(sub => sub.status === statusFilter)
    }

    if (searchTerm) {
      filtered = filtered.filter(sub => 
        sub.tasks?.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sub.submission_text?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    setFilteredSubmissions(filtered)
  }

  const filterPayoutRequests = () => {
    let filtered = payoutRequests

    if (payoutStatusFilter !== 'all') {
      filtered = filtered.filter(req => req.status === payoutStatusFilter)
    }

    if (payoutSearchTerm) {
      filtered = filtered.filter(req => 
        req.profiles?.display_name?.toLowerCase().includes(payoutSearchTerm.toLowerCase()) ||
        req.upi_id?.toLowerCase().includes(payoutSearchTerm.toLowerCase()) ||
        req.profiles?.phone?.includes(payoutSearchTerm)
      )
    }

    setFilteredPayoutRequests(filtered)
  }

  const handleApprove = async (submission: TaskSubmission) => {
    setProcessingId(submission.id)
    try {
      const response = await fetch('/api/admin/approve-submission', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ submissionId: submission.id })
      })

      if (response.ok) {
        toast({
          title: "Submission Approved",
          description: "Points have been awarded to the user",
        })
        fetchSubmissions()
        fetchStats()
      } else {
        const error = await response.json()
        toast({
          title: "Approval Failed",
          description: error.error,
          variant: "destructive"
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to approve submission",
        variant: "destructive"
      })
    } finally {
      setProcessingId(null)
    }
  }

  const handleReject = async (submission: TaskSubmission, reason: string) => {
    setProcessingId(submission.id)
    try {
      const response = await fetch('/api/admin/reject-submission', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          submissionId: submission.id,
          reason: reason
        })
      })

      if (response.ok) {
        toast({
          title: "Submission Rejected",
          description: "The submission has been rejected",
        })
        fetchSubmissions()
        fetchStats()
        setSelectedSubmission(null)
      } else {
        const error = await response.json()
        toast({
          title: "Rejection Failed",
          description: error.error,
          variant: "destructive"
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to reject submission",
        variant: "destructive"
      })
    } finally {
      setProcessingId(null)
    }
  }

  const handleProcessPayout = async (payout: PayoutRequest, action: string, notes?: string) => {
    setProcessingId(payout.id)
    try {
      const response = await fetch('/api/admin/process-payout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          requestId: payout.id,
          action: action,
          notes: notes
        })
      })

      if (response.ok) {
        const data = await response.json()
        toast({
          title: `Payout ${action.charAt(0).toUpperCase() + action.slice(1)}`,
          description: `Payout request has been ${action}ed successfully`,
        })
        fetchPayoutRequests()
        setSelectedPayout(null)
      } else {
        const error = await response.json()
        toast({
          title: `${action.charAt(0).toUpperCase() + action.slice(1)} Failed`,
          description: error.error,
          variant: "destructive"
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to ${action} payout`,
        variant: "destructive"
      })
    } finally {
      setProcessingId(null)
    }
  }

  const handleSuspendUser = async (userId: string, reason: string) => {
    setProcessingId(userId)
    try {
      const response = await fetch('/api/admin/suspend-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, reason })
      })

      if (response.ok) {
        toast({
          title: "User Suspended",
          description: "User has been suspended successfully",
        })
        fetchSuspiciousUsers()
      } else {
        const error = await response.json()
        toast({
          title: "Suspension Failed",
          description: error.error,
          variant: "destructive"
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to suspend user",
        variant: "destructive"
      })
    } finally {
      setProcessingId(null)
    }
  }

  const handleLiftSuspension = async (userId: string) => {
    setProcessingId(userId)
    try {
      const response = await fetch('/api/admin/lift-suspension', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId })
      })

      if (response.ok) {
        toast({
          title: "Suspension Lifted",
          description: "User suspension has been lifted successfully",
        })
        fetchSuspiciousUsers()
      } else {
        const error = await response.json()
        toast({
          title: "Failed to Lift Suspension",
          description: error.error,
          variant: "destructive"
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to lift suspension",
        variant: "destructive"
      })
    } finally {
      setProcessingId(null)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800"><Clock className="h-3 w-3 mr-1" />Pending</Badge>
      case 'approved':
        return <Badge className="bg-green-100 text-green-800"><CheckIcon className="h-3 w-3 mr-1" />Approved</Badge>
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getPayoutStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800"><Clock className="h-3 w-3 mr-1" />Pending</Badge>
      case 'processing':
        return <Badge className="bg-blue-100 text-blue-800"><Loader2 className="h-3 w-3 mr-1" />Processing</Badge>
      case 'approved':
        return <Badge className="bg-green-100 text-green-800"><CheckIcon className="h-3 w-3 mr-1" />Approved</Badge>
      case 'paid':
        return <Badge className="bg-green-100 text-green-800"><CheckIcon className="h-3 w-3 mr-1" />Paid</Badge>
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-96">
          <CardContent className="pt-6 text-center">
            <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Access Denied</h2>
            <p className="text-muted-foreground">You don't have admin access to this page.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage tasks and submissions</p>
          </div>
          <Button onClick={() => window.location.href = '/dashboard'}>
            Back to Dashboard
          </Button>
        </div>

        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Tasks</CardTitle>
                <FileText className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalTasks}</div>
                <p className="text-xs text-muted-foreground">
                  {stats.activeTasks} active
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Submissions</CardTitle>
                <Users className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalSubmissions}</div>
                <p className="text-xs text-muted-foreground">
                  {stats.pendingSubmissions} pending
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Approved</CardTitle>
                <CheckIcon className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.approvedSubmissions}</div>
                <p className="text-xs text-muted-foreground">
                  {stats.totalSubmissions > 0 ? 
                    Math.round((stats.approvedSubmissions / stats.totalSubmissions) * 100) : 0}% approval rate
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Rejected</CardTitle>
                <XCircle className="h-4 w-4 text-red-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.rejectedSubmissions}</div>
                <p className="text-xs text-muted-foreground">
                  {stats.totalSubmissions > 0 ? 
                    Math.round((stats.rejectedSubmissions / stats.totalSubmissions) * 100) : 0}% rejection rate
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Payout Stats Cards */}
        {payoutStats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Payouts</CardTitle>
                <Wallet className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{payoutStats.total}</div>
                <p className="text-xs text-muted-foreground">
                  All time
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pending</CardTitle>
                <Clock className="h-4 w-4 text-yellow-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{payoutStats.pending}</div>
                <p className="text-xs text-muted-foreground">
                  Awaiting approval
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Approved</CardTitle>
                <CheckIcon className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{payoutStats.approved}</div>
                <p className="text-xs text-muted-foreground">
                  Ready to process
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Paid</CardTitle>
                <IndianRupee className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{payoutStats.paid}</div>
                <p className="text-xs text-muted-foreground">
                  Successfully paid
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Management Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="submissions">Submissions</TabsTrigger>
            <TabsTrigger value="payouts">Payouts</TabsTrigger>
            <TabsTrigger value="fraud">Fraud Center</TabsTrigger>
          </TabsList>

          <TabsContent value="submissions">
            {/* Submissions Management */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Submissions Management</CardTitle>
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <input
                        type="text"
                        placeholder="Search submissions..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 pr-4 py-2 border rounded-md text-sm"
                      />
                    </div>
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Filter" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="approved">Approved</SelectItem>
                        <SelectItem value="rejected">Rejected</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Task</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Score</TableHead>
                      <TableHead>Submitted</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredSubmissions.map((submission) => (
                      <TableRow key={submission.id}>
                        <TableCell className="font-medium">
                          {submission.tasks?.title || 'Unknown Task'}
                        </TableCell>
                        <TableCell>{submission.user_id.slice(0, 8)}...</TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {submission.tasks?.task_type || 'unknown'}
                          </Badge>
                        </TableCell>
                        <TableCell>{getStatusBadge(submission.status)}</TableCell>
                        <TableCell>
                          {submission.auto_score ? `${Math.round(submission.auto_score * 100)}%` : '-'}
                        </TableCell>
                        <TableCell>
                          {new Date(submission.created_at).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setSelectedSubmission(submission)}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            {submission.status === 'pending' && (
                              <>
                                <Button
                                  size="sm"
                                  onClick={() => handleApprove(submission)}
                                  disabled={processingId === submission.id}
                                >
                                  {processingId === submission.id ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <CheckIcon className="h-4 w-4" />
                                  )}
                                </Button>
                                <RejectDialog 
                                  submission={submission}
                                  onReject={handleReject}
                                  processingId={processingId}
                                />
                              </>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="payouts">
            {/* Payouts Management */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Payouts Management</CardTitle>
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <input
                        type="text"
                        placeholder="Search payouts..."
                        value={payoutSearchTerm}
                        onChange={(e) => setPayoutSearchTerm(e.target.value)}
                        className="pl-10 pr-4 py-2 border rounded-md text-sm"
                      />
                    </div>
                    <Select value={payoutStatusFilter} onValueChange={setPayoutStatusFilter}>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Filter" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="processing">Processing</SelectItem>
                        <SelectItem value="approved">Approved</SelectItem>
                        <SelectItem value="paid">Paid</SelectItem>
                        <SelectItem value="rejected">Rejected</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>UPI ID</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPayoutRequests.map((payout) => (
                      <TableRow key={payout.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{payout.profiles?.display_name || 'Unknown'}</div>
                            <div className="text-sm text-muted-foreground">{payout.profiles?.phone}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="font-semibold">₹{payout.amount_inr.toFixed(2)}</div>
                          <div className="text-xs text-muted-foreground">({payout.amount_points} points)</div>
                        </TableCell>
                        <TableCell>
                          <code className="text-xs bg-muted px-2 py-1 rounded">
                            {payout.upi_id}
                          </code>
                        </TableCell>
                        <TableCell>{getPayoutStatusBadge(payout.status)}</TableCell>
                        <TableCell>
                          {new Date(payout.created_at).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setSelectedPayout(payout)}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            {payout.status === 'pending' && (
                              <>
                                <Button
                                  size="sm"
                                  onClick={() => handleProcessPayout(payout, 'approve')}
                                  disabled={processingId === payout.id}
                                >
                                  {processingId === payout.id ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <CheckIcon className="h-4 w-4" />
                                  )}
                                </Button>
                                <PayoutRejectDialog 
                                  payout={payout}
                                  onReject={(notes) => handleProcessPayout(payout, 'reject', notes)}
                                  processingId={processingId}
                                />
                              </>
                            )}
                            {payout.status === 'approved' && (
                              <Button
                                size="sm"
                                onClick={() => handleProcessPayout(payout, 'mark_paid')}
                                disabled={processingId === payout.id}
                              >
                                {processingId === payout.id ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  <CheckIcon className="h-4 w-4" />
                                )}
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="fraud">
            {/* Fraud Center */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Fraud Center
                  </CardTitle>
                  <Button onClick={fetchSuspiciousUsers} variant="outline" size="sm">
                    Refresh
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {suspiciousUsers.length === 0 ? (
                  <div className="text-center py-8">
                    <Shield className="h-12 w-12 text-green-500 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No Suspicious Activity</h3>
                    <p className="text-muted-foreground">All users appear to be following the rules.</p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Alerts</TableHead>
                        <TableHead>Devices</TableHead>
                        <TableHead>IP Addresses</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {suspiciousUsers.map((user) => (
                        <TableRow key={user.user_id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{user.username}</div>
                              <div className="text-sm text-muted-foreground">{user.email}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            {user.is_suspended ? (
                              <Badge className="bg-red-100 text-red-800">
                                <UserX className="h-3 w-3 mr-1" />
                                Suspended
                              </Badge>
                            ) : (
                              <Badge className="bg-yellow-100 text-yellow-800">
                                <AlertTriangle className="h-3 w-3 mr-1" />
                                Suspicious
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="space-y-1">
                              <div className="text-sm font-medium">{user.alert_count} alerts</div>
                              {user.latest_alert_type && (
                                <Badge variant="outline" className="text-xs">
                                  {user.latest_alert_type}
                                </Badge>
                              )}
                              {user.latest_severity && (
                                <Badge 
                                  variant={user.latest_severity === 'high' ? 'destructive' : 'secondary'}
                                  className="text-xs"
                                >
                                  {user.latest_severity}
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              {user.device_count} device{user.device_count !== 1 ? 's' : ''}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="max-w-32">
                              <div className="text-xs space-y-1">
                                {user.ip_addresses.slice(0, 2).map((ip, index) => (
                                  <code key={index} className="bg-muted px-1 py-0.5 rounded text-xs">
                                    {ip}
                                  </code>
                                ))}
                                {user.ip_addresses.length > 2 && (
                                  <div className="text-muted-foreground">
                                    +{user.ip_addresses.length - 2} more
                                  </div>
                                )}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {!user.is_suspended ? (
                                <SuspendUserDialog 
                                  user={user}
                                  onSuspend={handleSuspendUser}
                                  processingId={processingId}
                                />
                              ) : (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleLiftSuspension(user.user_id)}
                                  disabled={processingId === user.user_id}
                                >
                                  {processingId === user.user_id ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    'Lift'
                                  )}
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Submission Details Dialog */}
        <Dialog open={!!selectedSubmission} onOpenChange={() => setSelectedSubmission(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Submission Details</DialogTitle>
            </DialogHeader>
            {selectedSubmission && (
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold">Task</h4>
                  <p className="text-sm text-muted-foreground">
                    {selectedSubmission.tasks?.title}
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold">Submission</h4>
                  <p className="text-sm bg-muted p-3 rounded-md">
                    {selectedSubmission.submission_text || 'No text submission'}
                  </p>
                </div>
                {selectedSubmission.submission_url && (
                  <div>
                    <h4 className="font-semibold">Audio URL</h4>
                    <a 
                      href={selectedSubmission.submission_url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-sm text-blue-600 hover:underline"
                    >
                      {selectedSubmission.submission_url}
                    </a>
                  </div>
                )}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold">Auto Score</h4>
                    <p className="text-sm">
                      {selectedSubmission.auto_score ? 
                        `${Math.round(selectedSubmission.auto_score * 100)}%` : 'Not scored'
                      }
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold">Status</h4>
                    <div>{getStatusBadge(selectedSubmission.status)}</div>
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Payout Details Dialog */}
        <Dialog open={!!selectedPayout} onOpenChange={() => setSelectedPayout(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Payout Request Details</DialogTitle>
            </DialogHeader>
            {selectedPayout && (
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold">User Information</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Name</p>
                      <p className="font-medium">{selectedPayout.profiles?.display_name || 'Unknown'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Phone</p>
                      <p className="font-medium">{selectedPayout.profiles?.phone || 'Not provided'}</p>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold">Payout Details</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Amount</p>
                      <p className="font-semibold">₹{selectedPayout.amount_inr.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Points Used</p>
                      <p className="font-semibold">{selectedPayout.amount_points}</p>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold">UPI Information</h4>
                  <div className="bg-muted p-3 rounded-md">
                    <code className="text-sm">{selectedPayout.upi_id}</code>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold">Status</h4>
                    <div>{getPayoutStatusBadge(selectedPayout.status)}</div>
                  </div>
                  <div>
                    <h4 className="font-semibold">Requested Date</h4>
                    <p className="text-sm">{new Date(selectedPayout.created_at).toLocaleDateString()}</p>
                  </div>
                </div>
                {selectedPayout.admin_notes && (
                  <div>
                    <h4 className="font-semibold">Admin Notes</h4>
                    <p className="text-sm bg-muted p-3 rounded-md">{selectedPayout.admin_notes}</p>
                  </div>
                )}
                {selectedPayout.paid_at && (
                  <div>
                    <h4 className="font-semibold">Paid Date</h4>
                    <p className="text-sm">{new Date(selectedPayout.paid_at).toLocaleDateString()}</p>
                  </div>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}

function RejectDialog({ 
  submission, 
  onReject, 
  processingId 
}: { 
  submission: TaskSubmission
  onReject: (submission: TaskSubmission, reason: string) => void
  processingId: string | null
}) {
  const [reason, setReason] = useState('')
  const [isOpen, setIsOpen] = useState(false)

  const handleReject = () => {
    if (reason.trim()) {
      onReject(submission, reason)
      setIsOpen(false)
      setReason('')
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="destructive">
          {processingId === submission.id ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <XCircle className="h-4 w-4" />
          )}
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Reject Submission</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium">Reason for rejection</label>
            <Textarea
              placeholder="Please provide a reason for rejecting this submission..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={3}
            />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setIsOpen(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleReject}
              disabled={!reason.trim() || processingId === submission.id}
            >
              {processingId === submission.id ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Rejecting...
                </>
              ) : (
                <>
                  <XCircle className="h-4 w-4 mr-2" />
                  Reject Submission
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function PayoutRejectDialog({ 
  payout, 
  onReject, 
  processingId 
}: { 
  payout: PayoutRequest
  onReject: (payout: PayoutRequest, reason: string) => void
  processingId: string | null
}) {
  const [reason, setReason] = useState('')
  const [isOpen, setIsOpen] = useState(false)

  const handleReject = () => {
    if (reason.trim()) {
      onReject(payout, reason)
      setIsOpen(false)
      setReason('')
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="destructive">
          {processingId === payout.id ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <XCircle className="h-4 w-4" />
          )}
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Reject Payout Request</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium">Reason for rejection</label>
            <Textarea
              placeholder="Please provide a reason for rejecting this payout request..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={3}
            />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setIsOpen(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleReject}
              disabled={!reason.trim() || processingId === payout.id}
            >
              {processingId === payout.id ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Rejecting...
                </>
              ) : (
                <>
                  <XCircle className="h-4 w-4 mr-2" />
                  Reject Payout
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function SuspendUserDialog({ 
  user, 
  onSuspend, 
  processingId 
}: { 
  user: SuspiciousUser
  onSuspend: (userId: string, reason: string) => void
  processingId: string | null
}) {
  const [reason, setReason] = useState('')
  const [isOpen, setIsOpen] = useState(false)

  const handleSuspend = () => {
    if (reason.trim()) {
      onSuspend(user.user_id, reason)
      setIsOpen(false)
      setReason()
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="destructive">
          <UserX className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Suspend User</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <p className="text-sm text-muted-foreground mb-2">
              Suspend user: <strong>{user.username}</strong> ({user.email})
            </p>
            <p className="text-sm text-muted-foreground mb-2">
              Alert count: {user.alert_count} | Devices: {user.device_count}
            </p>
          </div>
          <div>
            <label className="text-sm font-medium">Reason for suspension</label>
            <Textarea
              placeholder="Please provide a reason for suspending this user..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={3}
            />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setIsOpen(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleSuspend}
              disabled={!reason.trim() || processingId === user.user_id}
            >
              {processingId === user.user_id ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Suspending...
                </>
              ) : (
                <>
                  <UserX className="h-4 w-4 mr-2" />
                  Suspend User
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
