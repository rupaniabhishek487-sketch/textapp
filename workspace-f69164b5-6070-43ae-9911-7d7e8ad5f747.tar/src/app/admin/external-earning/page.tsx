'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { 
  Settings, 
  Save, 
  Plus, 
  AlertCircle, 
  CheckCircle,
  TrendingUp,
  Trash2,
  ExternalLink
} from 'lucide-react'

interface ExternalOfferConfig {
  id: string
  title: string
  description: string
  reward_points: number
  partner_name: string
  offer_url: string
  category: 'survey' | 'offerwall' | 'video' | 'app_install'
  active: boolean
  custom_config?: any
}

export default function AdminExternalEarningPage() {
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)
  const [offers, setOffers] = useState<ExternalOfferConfig[]>([])
  const [editingOffer, setEditingOffer] = useState<ExternalOfferConfig | null>(null)
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    reward_points: 10,
    partner_name: '',
    offer_url: '',
    category: 'survey',
    active: true
  })

  useEffect(() => {
    fetchOffers()
  }, [])

  const fetchOffers = async () => {
    try {
      // Mock data - in real implementation, this would come from database
      const mockOffers: ExternalOfferConfig[] = [
        {
          id: '1',
          title: 'Daily Survey - Mobile Apps',
          description: 'Complete daily surveys and earn points from mobile app offers',
          reward_points: 50,
          partner_name: 'SurveyPro',
          offer_url: 'https://survey.example.com/offers',
          category: 'survey',
          active: true
        },
        {
          id: '2',
          title: 'Game Install - High Rewards',
          description: 'Install and play games to earn maximum points',
          reward_points: 100,
          partner_name: 'GameStudio',
          offer_url: 'https://games.example.com/offers',
          category: 'app_install',
          active: true
        },
        {
          id: '3',
          title: 'Video Ads - Entertainment',
          description: 'Watch entertaining video content and earn points',
          reward_points: 30,
          partner_name: 'VideoAdNetwork',
          offer_url: 'https://video.example.com/offers',
          category: 'video',
          active: true
        },
        {
          id: '4',
          title: 'Newsletter Signup',
          description: 'Subscribe to newsletters and earn instant bonus points',
          reward_points: 20,
          partner_name: 'Earnify',
          offer_url: '#',
          category: 'offerwall',
          active: true
        }
      ]

      setOffers(mockOffers)
      setLoading(false)
    } catch (error) {
      console.error('Failed to fetch external offers:', error)
      toast({
        title: "Error",
        description: "Failed to load external offers",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSaveOffer = async () => {
    if (!formData.title || !formData.reward_points || !formData.partner_name || !formData.offer_url || !formData.category) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      })
      return
    }

    try {
      const response = await fetch('/api/admin/external-earning', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
      })

      if (response.ok) {
        const data = await response.json()
        toast({
          title: "Offer Saved",
          description: "External offer configuration saved successfully",
        })
        
        // Reset form
        setFormData({
          title: '',
          description: '',
          reward_points: 10,
          partner_name: '',
          offer_url: '',
          category: 'survey',
          active: true
        })
        setEditingOffer(null)
        
        // Refresh offers
        fetchOffers()
      } else {
        toast({
          title: "Save Failed",
          description: data.error || "Failed to save offer configuration",
          variant: "destructive"
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save offer configuration",
        variant: "destructive"
      })
    }
  }

  const handleEditOffer = (offer: ExternalOfferConfig) => {
    setEditingOffer(offer)
    setFormData({
      title: offer.title,
      description: offer.description,
      reward_points: offer.reward_points,
      partner_name: offer.partner_name,
      offer_url: offer.offer_url,
      category: offer.category,
      active: offer.active
    })
  }

  const handleDeleteOffer = async (offerId: string) => {
    try {
      const response = await fetch('/api/admin/external-earning', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ offer_id })
        })

      if (response.ok) {
        toast({
          title: "Offer Deleted",
          description: "External offer configuration deleted successfully"
        })
        
        // Refresh offers
        fetchOffers()
      } else {
        toast({
          title: "Delete Failed",
          description: data.error || "Failed to delete offer configuration",
          variant: "destructive"
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete external offer",
        variant: "destructive"
      })
    }
  }

  const handleToggleOffer = async (offerId: string) => {
    try {
      const response = await fetch('/api/admin/external-earning', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          body: JSON.stringify({ offer_id, active: false })
        })

      if (response.ok) {
        toast({
          title: "Offer Updated",
          description: "Offer status updated successfully"
        })
        
        // Refresh offers
        fetchOffers()
      } else {
          toast({
            title: "Update Failed",
            description: data.error || "Failed to update offer status",
            variant: "destructive"
          })
      }
    } catch (error) {
      toast({
          title: "Error",
          description: "Failed to update offer status",
            variant: "destructive"
      })
    }
  }

  const categories = [
    { id: 'all', name: 'All Offers', icon: 'Grid3X3' },
    { id: 'survey', name: 'Surveys', icon: 'FileText' },
    { id: 'offerwall', name: 'Offerwall', icon: 'Gift' },
    { id: 'video', name: 'Videos', icon: 'Play' },
    { id: 'app_install', name: 'Apps', icon: 'Smartphone' }
  ]

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2">External Earning Admin</h1>
          <p className="text-muted-foreground">
            Configure external offerwall and video ads for users
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Offers</CardTitle>
              <Settings className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{offers.length}</div>
              <p className="text-xs text-muted-foreground">
                Configured external offers
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Offers</CardTitle>
              <TrendingUp className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{offers.filter(o => o.active).length}</div>
              <p className="text-xs text-muted-foreground">
                Currently active offers
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Reward Pool</CardTitle>
              <Award className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {offers.reduce((sum, offer) => sum + offer.reward_points, 0)}
              </div>
              <p className="text-xs text-muted-foreground">
                Points available for rewards
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Offer Management */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <CardTitle>External Offers Management</CardTitle>
              <Button 
                onClick={() => setEditingOffer({
                  title: '',
                  description: '',
                  reward_points: 10,
                  partner_name: '',
                  offer_url: '',
                  category: 'survey',
                  active: true
                })}
                size="sm"
              >
                <Plus className="h-4 w-4" />
                Add New Offer
              </Button>
            </CardHeader>
          </CardHeader>
            <CardContent className="space-y-6">
              {editingOffer ? (
                <div className="border rounded-lg p-4 bg-muted/50">
                  <h3 className="text-lg font-semibold mb-4">Edit Offer</h3>
                  
                  <div className="space-y-4">
                    <div className="mb-4">
                      <Label htmlFor="title">Title</Label>
                      <Input
                        id="title"
                        value={formData.title}
                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                        placeholder="Enter offer title"
                        className="w-full"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={formData.description}
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        placeholder="Describe the offer"
                        rows={3}
                        className="w-full"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="reward_points">Reward Points</Label>
                      <Input
                        id="reward_points"
                        type="number"
                        value={formData.reward_points}
                        onChange={(e) => setFormData({ ...formData, reward_points: parseInt(e.target.value) || 0)})}
                        placeholder="Points awarded for completion"
                        className="w-full"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="partner_name">Partner Name</Label>
                      <Input
                        id="partner_name"
                        value={formData.partner_name}
                        onChange={(e) => setFormData({ ...formData, partner_name: e.target.value })}
                        placeholder="Partner company name"
                        className="w-full"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="offer_url">Offer URL</Label>
                        <Input
                        id="offer_url"
                        value={formData.offer_url}
                        onChange={(e) => setFormData({ ...formData, offer_url: e.target.value })}
                        placeholder="https://example.com/offer"
                        className="w-full"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="category">Category</Label>
                      <select 
                        id="category"
                        value={formData.category}
                        onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                        className="w-full"
                        >
                          <option value="survey">Survey</option>
                            <option value="offerwall">Offerwall</option>
                            <option value="video">Video</option>
                            <option value="app_install">App Install</option>
                          </select>
                        </select>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 pt-4">
                    <div className="flex items-center gap-4">
                      <Switch
                        id="active"
                        checked={formData.active}
                        onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
                        />
                        <Label htmlFor="active">Active</Label>
                      </Switch>
                      </div>
                  </div>
                  
                  <div className="flex gap-2 pt-4">
                    <Button 
                      variant="outline"
                      onClick={() => setEditingOffer(null)}
                    >
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleSaveOffer}
                      disabled={!formData.title || !formData.reward_points}
                    >
                      Save Offer
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <CardContent className="space-y-4">
              <div className="text-center py-8">
                <Plus className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-muted-foreground">Create New Offerh3>
                <p className="text-sm text-muted-foreground">
                  Configure a new external offer for users
                </p>
              </div>
            </CardContent>
          )}
        </Card>

        {/* Offers List */}
        <Card>
          <CardHeader>
            <CardTitle>Configured Offers</CardTitle>
          </CardHeader>
          <CardContent>
            {offers.length === 0 ? (
              <div className="text-center py-8">
                <Settings className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-muted-foreground">No Offers Yet</h3>
                <p className="text-sm text-muted-foreground">
                  Create your first external offer to get started
                </p>
              </div>
            </div>
            ) : (
              <div className="space-y-4">
                {offers.map((offer) => (
                  <Card key={offer.id} className="hover:shadow-md transition-shadow cursor-pointer">
                    <CardHeader className="relative">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getCategoryColor(offer.category)}`}>
                          <span className="text-white font-bold text-sm">
                            {offer.category.charAt(0).toUpperCase()}
                          </span>
                        </span>
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">{offer.title}</h4>
                        <p className="text-sm text-muted-foreground">{offer.description}</p>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-purple-600">+{offer.reward_points}</div>
                      <p className="text-xs text-muted-foreground">points</p>
                        </div>
                    </div>
                  </div>
                </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="font-medium">{offer.partner_name}</span>
                      <span className="mx-2">•</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(offer.category)}`}>
                        {offer.category}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <ExternalLink className="h-4 w-4" />
                      <span>{offer.offer_url}</span>
                    </div>
                    </div>
                    
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      <span>{offer.reward_points} points</span>
                      <span className="mx-2">•</span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Badge className={offer.active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'>
                        {offer.active ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button 
                      variant="outline"
                      size="sm"
                      onClick={() => handleEditOffer(offer)}
                    >
                      Edit
                    </Button>
                    <Button 
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDeleteOffer(offer.id)}
                    >
                      <Trash2 className="h-4" />
                      Delete
                    </Button>
                    <Button 
                      variant="outline"
                      size="sm"
                      onClick={() => handleToggleOffer(offer.id)}
                        {offer.active ? 'Deactivate' : 'Activate'}
                    >
                      {offer.active ? 'Deactivate' : 'Activate'}
                    </Button>
                  </div>
                </div>
              </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Info Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-yellow-600" />
              Configuration Guide
            </CardHeader>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <h4 className="font-semibold">Offer Categories</h4>
              <p className="text-sm text-muted-foreground">
                <strong>Surveys:</strong> - User feedback and opinion surveys
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold">Offerwall:</strong> - Mobile Apps</strong>
              <p className="text-sm text-muted-foreground">
                Install and try mobile applications
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold">Video Ads:</strong> - Entertainment</strong>
              <p className="text-sm text-muted-foreground">
                Watch entertaining videos and earn points
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold">App Installs:</strong> - Install and play mobile games
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold">Newsletter:</strong> - Subscribe to newsletters for instant bonus
              </p>
            </div>
          </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}