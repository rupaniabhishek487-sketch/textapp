"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { useToast } from '@/hooks/use-toast'
import { useAuth } from '@/components/AuthProvider'
import { 
  Wallet, 
  IndianRupee, 
  ArrowUpRight, 
  History, 
  AlertCircle, 
  CheckCircle, 
  Clock, 
  XCircle,
  Info,
  Calculator,
  Timer,
  Shield
} from 'lucide-react'
import { PayoutRequest } from '@/types/supabase'

interface WalletStats {
  total_points: number
  balance_inr: number
  total_earnings_inr: number
}

interface Config {
  points_to_inr_rate: number
  min_payout_threshold: number
  max_payout_amount: number
  payout_processing_time: string
  payout_methods: string[]
  manual_payout_instructions: any
}

export default function PayoutPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState<WalletStats | null>(null)
  const [config, setConfig] = useState<Config | null>(null)
  const [payoutRequests, setPayoutRequests] = useState<PayoutRequest[]>([])
  const [upiId, setUpiId] = useState('')
  const [payoutAmount, setPayoutAmount] = useState('')
  const [processing, setProcessing] = useState(false)
  const [showInstructions, setShowInstructions] = useState(false)

  useEffect(() => {
    if (user) {
      Promise.all([
        fetchWalletStats(),
        fetchConfig(),
        fetchPayoutRequests()
      ]).finally(() => setLoading(false))
    }
  }, [user])

  const fetchWalletStats = async () => {
    try {
      const response = await fetch('/api/wallet/stats')
      if (!response.ok) throw new Error('Failed to fetch wallet stats')
      const data = await response.json()
      setStats(data.stats)
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      })
    }
  }

  const fetchConfig = async () => {
    try {
      const response = await fetch('/api/wallet/config')
      if (!response.ok) throw new Error('Failed to fetch config')
      const data = await response.json()
      setConfig(data.config)
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      })
    }
  }

  const fetchPayoutRequests = async () => {
    try {
      const response = await fetch('/api/payout/requests')
      if (!response.ok) throw new Error('Failed to fetch payout requests')
      const data = await response.json()
      setPayoutRequests(data.requests || [])
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      })
    }
  }

  const handleRequestPayout = async () => {
    if (!upiId.trim()) {
      toast({
        title: "Error",
        description: "Please enter your UPI ID",
        variant: "destructive"
      })
      return
    }

    const amount = parseFloat(payoutAmount)
    if (!amount || amount <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid amount",
        variant: "destructive"
      })
      return
    }

    if (amount < config.min_payout_threshold) {
      toast({
        title: "Error",
        description: `Minimum payout amount is ₹${config.min_payout_threshold}`,
        variant: "destructive"
      })
      return
    }

    if (amount > config.max_payout_amount) {
      toast({
        title: "Error",
        description: `Maximum payout amount is ₹${config.max_payout_amount}`,
        variant: "destructive"
      })
      return
    }

    if (amount > stats.balance_inr) {
      toast({
        title: "Error",
        description: "Insufficient balance",
        variant: "destructive"
      })
      return
    }

    // Validate UPI ID format
    const upiRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+$/
    if (!upiRegex.test(upiId)) {
      toast({
        title: "Error",
        description: "Please enter a valid UPI ID (e.g., username@ybl)",
        variant: "destructive"
      })
      return
    }

    setProcessing(true)
    try {
      const response = await fetch('/api/payout/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          upiId: upiId.trim(),
          amount: amount
        })
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || 'Failed to request payout')
      }

      const data = await response.json()
      toast({
        title: "Payout Requested!",
        description: `Your payout request for ₹${amount} has been submitted successfully.`,
      })

      // Reset form
      setUpiId('')
      setPayoutAmount('')
      
      // Refresh data
      await Promise.all([
        fetchWalletStats(),
        fetchPayoutRequests()
      ])

    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      })
    } finally {
      setProcessing(false)
    }
  }

  const getMaxPayoutAmount = () => {
    if (!stats || !config) return 0
    return Math.min(stats.balance_inr, config.max_payout_amount)
  }

  const getPayoutStatusBadge = (status: string) => {
    const variants: Record<string, { label: string; className: string; icon: React.ReactNode }> = {
      'pending': { 
        label: 'Pending', 
        className: 'bg-yellow-100 text-yellow-800', 
        icon: <Clock className="h-3 w-3" /> 
      },
      'processing': { 
        label: 'Processing', 
        className: 'bg-blue-100 text-blue-800', 
        icon: <Timer className="h-3 w-3" /> 
      },
      'approved': { 
        label: 'Approved', 
        className: 'bg-green-100 text-green-800', 
        icon: <CheckCircle className="h-3 w-3" /> 
      },
      'paid': { 
        label: 'Paid', 
        className: 'bg-green-100 text-green-800', 
        icon: <CheckCircle className="h-3 w-3" /> 
      },
      'rejected': { 
        label: 'Rejected', 
        className: 'bg-red-100 text-red-800', 
        icon: <XCircle className="h-3 w-3" /> 
      }
    }
    
    const variant = variants[status] || { 
      label: status, 
      className: 'bg-gray-100 text-gray-800', 
      icon: <AlertCircle className="h-3 w-3" /> 
    }
    
    return (
      <Badge className={variant.className}>
        {variant.icon}
        <span className="ml-1">{variant.label}</span>
      </Badge>
    )
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-600"></div>
      </div>
    )
  }

  if (!user || !stats || !config) {
    return null
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Payout</h1>
            <p className="text-muted-foreground">Request and manage your payouts</p>
          </div>
          <Button onClick={() => window.location.href = '/wallet'}>
            <Wallet className="h-4 w-4 mr-2" />
            Back to Wallet
          </Button>
        </div>

        {/* Wallet Balance Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wallet className="h-5 w-5" />
              Current Balance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-3xl font-bold text-green-600">{stats.total_points.toLocaleString()}</div>
                <div className="text-sm text-muted-foreground">Total Points</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-3xl font-bold text-blue-600">₹{stats.balance_inr.toFixed(2)}</div>
                <div className="text-sm text-muted-foreground">Available Balance</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-3xl font-bold text-purple-600">₹{getMaxPayoutAmount().toFixed(2)}</div>
                <div className="text-sm text-muted-foreground">Max Payout Amount</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payout Request Form */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Request Payout</CardTitle>
              <Dialog open={showInstructions} onOpenChange={setShowInstructions}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Info className="h-4 w-4 mr-2" />
                    Payout Instructions
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <Info className="h-5 w-5" />
                      {config.manual_payout_instructions.title}
                    </DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <p className="text-muted-foreground">
                      {config.manual_payout_instructions.description}
                    </p>
                    <div className="space-y-2">
                      <h4 className="font-semibold">Process:</h4>
                      <ol className="list-decimal list-inside space-y-1 text-sm">
                        {config.manual_payout_instructions.steps.map((step: string, index: number) => (
                          <li key={index}>{step}</li>
                        ))}
                      </ol>
                    </div>
                    <Alert>
                      <Shield className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Support:</strong> {config.manual_payout_instructions.support}
                      </AlertDescription>
                    </Alert>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Conversion Info */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Alert>
                <Calculator className="h-4 w-4" />
                <AlertDescription>
                  <strong>Conversion:</strong> {config.points_to_inr_rate} points = ₹1
                </AlertDescription>
              </Alert>
              <Alert>
                <IndianRupee className="h-4 w-4" />
                <AlertDescription>
                  <strong>Minimum:</strong> ₹{config.min_payout_threshold}
                </AlertDescription>
              </Alert>
              <Alert>
                <Timer className="h-4 w-4" />
                <AlertDescription>
                  <strong>Processing:</strong> {config.payout_processing_time}
                </AlertDescription>
              </Alert>
            </div>

            {/* Payout Form */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="upiId">UPI ID</Label>
                <Input
                  id="upiId"
                  type="text"
                  placeholder="username@ybl"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  Enter your UPI ID (e.g., username@ybl, phone@paytm)
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="amount">Amount (₹)</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder={`Min: ₹${config.min_payout_threshold}`}
                  value={payoutAmount}
                  onChange={(e) => setPayoutAmount(e.target.value)}
                  min={config.min_payout_threshold}
                  max={getMaxPayoutAmount()}
                  step="0.01"
                />
                <p className="text-xs text-muted-foreground">
                  Max: ₹{getMaxPayoutAmount().toFixed(2)}
                </p>
              </div>
            </div>

            <Button
              onClick={handleRequestPayout}
              disabled={processing || !upiId.trim() || !payoutAmount}
              className="w-full"
            >
              {processing ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Processing...
                </>
              ) : (
                <>
                  <ArrowUpRight className="h-4 w-4 mr-2" />
                  Request Payout
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Payout History */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <History className="h-5 w-5" />
              Payout History
            </CardTitle>
          </CardHeader>
          <CardContent>
            {payoutRequests.length === 0 ? (
              <div className="text-center py-8">
                <History className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No payout requests yet</h3>
                <p className="text-muted-foreground">Your payout requests will appear here once you submit them.</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>UPI ID</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Notes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {payoutRequests.map((request) => (
                    <TableRow key={request.id}>
                      <TableCell>
                        {new Date(request.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <span className="font-semibold">₹{request.amount_inr.toFixed(2)}</span>
                        <div className="text-xs text-muted-foreground">
                          ({request.points_used} points)
                        </div>
                      </TableCell>
                      <TableCell>
                        <code className="text-xs bg-muted px-2 py-1 rounded">
                          {request.upi_id}
                        </code>
                      </TableCell>
                      <TableCell>
                        {getPayoutStatusBadge(request.status)}
                      </TableCell>
                      <TableCell>
                        {request.notes ? (
                          <span className="text-sm text-muted-foreground">{request.notes}</span>
                        ) : (
                          <span className="text-sm text-muted-foreground">-</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}