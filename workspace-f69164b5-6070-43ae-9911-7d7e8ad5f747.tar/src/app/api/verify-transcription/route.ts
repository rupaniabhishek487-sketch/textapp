import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseServerClient } from '@/lib/supabaseClient'

export async function POST(request: NextRequest) {
  try {
    const { submissionId, similarityScore } = await request.json()

    if (!submissionId || similarityScore === undefined) {
      return NextResponse.json({ 
        error: 'Missing required fields: submissionId, similarityScore' 
      }, { status: 400 })
    }

    const supabase = createSupabaseServerClient()
    
    // Get user from session (for admin verification)
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is admin (you can implement admin check logic here)
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!profile?.is_admin) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Fetch the submission
    const { data: submission, error: submissionError } = await supabase
      .from('task_submissions')
      .select(`
        *,
        tasks (
          id,
          title,
          task_type,
          reward_points
        )
      `)
      .eq('id', submissionId)
      .single()

    if (submissionError || !submission) {
      return NextResponse.json({ error: 'Submission not found' }, { status: 404 })
    }

    if (submission.status !== 'pending') {
      return NextResponse.json({ 
        error: 'Submission has already been processed' 
      }, { status: 400 })
    }

    // Determine approval based on similarity score
    const isApproved = similarityScore >= 0.90
    const status = isApproved ? 'approved' : 'rejected'
    const rewardPoints = isApproved ? submission.tasks.reward_points : 0

    // Update submission status
    const { data: updatedSubmission, error: updateError } = await supabase
      .from('task_submissions')
      .update({
        status,
        manual_score: similarityScore,
        reward_points: rewardPoints,
        reviewed_at: new Date().toISOString()
      })
      .eq('id', submissionId)
      .select()
      .single()

    if (updateError) {
      console.error('Update submission error:', updateError)
      return NextResponse.json({ error: 'Failed to update submission' }, { status: 500 })
    }

    // If approved, award points atomically
    if (isApproved) {
      const awardResult = await awardPointsAtomically(
        supabase, 
        submission.user_id, 
        rewardPoints, 
        'task_reward',
        {
          task_id: submission.task_id,
          task_title: submission.tasks.title,
          submission_id: submissionId,
          similarity_score: similarityScore
        }
      )

      if (!awardResult.success) {
        // Rollback submission update if points awarding fails
        await supabase
          .from('task_submissions')
          .update({
            status: 'pending',
            manual_score: null,
            reward_points: 0,
            reviewed_at: null
          })
          .eq('id', submissionId)

        return NextResponse.json({ 
          error: 'Failed to award points. Submission rolled back.' 
        }, { status: 500 })
      }
    }

    return NextResponse.json({
      success: true,
      submission: {
        id: updatedSubmission.id,
        status: updatedSubmission.status,
        similarityScore: similarityScore,
        pointsAwarded: rewardPoints,
        approved: isApproved
      }
    })

  } catch (error: any) {
    console.error('Verify transcription error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// Atomic function to award points
async function awardPointsAtomically(
  supabase: any,
  userId: string,
  points: number,
  kind: string,
  metadata: any
): Promise<{ success: boolean; error?: string }> {
  try {
    // Start a transaction by using RPC
    const { data, error } = await supabase.rpc('award_points_transaction', {
      p_user_id: userId,
      p_points: points,
      p_kind: kind,
      p_metadata: metadata
    })

    if (error) {
      console.error('Award points transaction error:', error)
      return { success: false, error: error.message }
    }

    return { success: true }
  } catch (error: any) {
    console.error('Award points error:', error)
    return { success: false, error: error.message }
  }
}