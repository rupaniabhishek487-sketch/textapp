import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseServerClient } from '@/lib/supabaseClient'

export async function GET(request: NextRequest) {
  try {
    const supabase = createSupabaseServerClient()
    
    // Get user from session
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Fetch user's claimed tasks (including claimed and submitted)
    const { data: claimedTasks, error: claimedError } = await supabase
      .from('task_submissions')
      .select(`
        *,
        tasks (
          id,
          title,
          task_type,
          reward_points,
          estimated_time
        )
      `)
      .eq('user_id', user.id)
      .in('status', ['claimed', 'submitted', 'approved', 'rejected'])
      .order('claimed_at', { ascending: false })

    if (claimedError) {
      console.error('Claimed tasks error:', claimedError)
      return NextResponse.json({ error: 'Failed to fetch claimed tasks' }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      claimedTasks: claimedTasks || []
    })

  } catch (error: any) {
    console.error('Get claimed tasks error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}