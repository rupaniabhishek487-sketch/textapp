import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseServerClient } from '@/lib/supabaseClient'

export async function POST(request: NextRequest) {
  try {
    const { requestId, action, notes } = await request.json()

    if (!requestId || !action) {
      return NextResponse.json({ 
        error: 'Missing required fields: requestId, action' 
      }, { status: 400 })
    }

    if (!['approve', 'reject', 'mark_paid'].includes(action)) {
      return NextResponse.json({ 
        error: 'Invalid action. Must be: approve, reject, or mark_paid' 
      }, { status: 400 })
    }

    const supabase = createSupabaseServerClient()
    
    // Get user from session
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!profile?.is_admin) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Fetch the payout request
    const { data: payoutRequest, error: requestError } = await supabase
      .from('payout_requests')
      .select('*')
      .eq('id', requestId)
      .single()

    if (requestError || !payoutRequest) {
      return NextResponse.json({ error: 'Payout request not found' }, { status: 404 })
    }

    // Check if request can be processed
    if (payoutRequest.status === 'paid' || payoutRequest.status === 'rejected') {
      return NextResponse.json({ 
        error: 'Payout request has already been processed' 
      }, { status: 400 })
    }

    let updateData: any = {
      updated_at: new Date().toISOString()
    }

    // Handle different actions
    if (action === 'approve') {
      updateData.status = 'approved'
      updateData.admin_notes = notes || 'Approved by admin'
      
      // Deduct points from user balance (atomic operation)
      const deductResult = await deductPointsAtomically(
        supabase,
        payoutRequest.user_id,
        payoutRequest.amount_points,
        payoutRequest.amount_inr
      )

      if (!deductResult.success) {
        return NextResponse.json({ 
          error: 'Failed to deduct points. Please try again.' 
        }, { status: 500 })
      }

      // Create transaction record
      await supabase
        .from('transactions')
        .insert({
          user_id: payoutRequest.user_id,
          kind: 'payout',
          points: -payoutRequest.amount_points,
          inr_value: -payoutRequest.amount_inr,
          meta: {
            payout_request_id: requestId,
            upi_id: payoutRequest.upi_id,
            approved_by: user.id,
            approved_at: new Date().toISOString()
          }
        })

    } else if (action === 'reject') {
      updateData.status = 'rejected'
      updateData.admin_notes = notes || 'Rejected by admin'
      
    } else if (action === 'mark_paid') {
      if (payoutRequest.status !== 'approved') {
        return NextResponse.json({ 
          error: 'Payout request must be approved before marking as paid' 
        }, { status: 400 })
      }
      updateData.status = 'paid'
      updateData.admin_notes = notes || 'Marked as paid by admin'
      updateData.paid_at = new Date().toISOString()
    }

    // Update payout request
    const { data: updatedRequest, error: updateError } = await supabase
      .from('payout_requests')
      .update(updateData)
      .eq('id', requestId)
      .select()
      .single()

    if (updateError) {
      console.error('Update payout request error:', updateError)
      return NextResponse.json({ error: 'Failed to update payout request' }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      request: updatedRequest,
      action: action
    })

  } catch (error: any) {
    console.error('Process payout request error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// Atomic function to deduct points
async function deductPointsAtomically(
  supabase: any,
  userId: string,
  points: number,
  inrValue: number
): Promise<{ success: boolean; error?: string }> {
  try {
    // Use database function for atomic operation
    const { data, error } = await supabase.rpc('deduct_points_transaction', {
      p_user_id: userId,
      p_points: points,
      p_inr_value: inrValue
    })

    if (error) {
      console.error('Deduct points transaction error:', error)
      return { success: false, error: error.message }
    }

    return { success: true, data }
  } catch (error: any) {
    console.error('Deduct points error:', error)
    return { success: false, error: error.message }
  }
}