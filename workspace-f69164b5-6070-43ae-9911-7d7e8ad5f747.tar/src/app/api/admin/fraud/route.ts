import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/utils/supabase/server'

export async function GET() {
  try {
    const supabase = createClient()
    
    // Get suspicious users using the database function
    const { data: suspiciousUsers, error } = await supabase.rpc('get_suspicious_users')
    
    if (error) {
      console.error('Error fetching suspicious users:', error)
      return NextResponse.json({ error: 'Failed to fetch suspicious users' }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      users: suspiciousUsers || []
    })

  } catch (error) {
    console.error('Fraud center error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}