import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseServerClient } from '@/lib/supabaseClient'

export async function GET(request: NextRequest) {
  try {
    const supabase = createSupabaseServerClient()
    
    // Get user from session
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!profile?.is_admin) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Fetch all payout requests with user details
    const { data: requests, error: requestsError } = await supabase
      .from('payout_requests')
      .select(`
        *,
        profiles (
          display_name,
          phone,
          total_points,
          balance_inr
        )
      `)
      .order('created_at', { ascending: false })

    if (requestsError) {
      console.error('Payout requests error:', requestsError)
      return NextResponse.json({ error: 'Failed to fetch payout requests' }, { status: 500 })
    }

    // Get statistics
    const { data: stats } = await supabase
      .from('payout_requests')
      .select('status')
      .order('created_at', { ascending: false })

    const statsData = {
      total: stats?.length || 0,
      pending: stats?.filter(r => r.status === 'pending').length || 0,
      processing: stats?.filter(r => r.status === 'processing').length || 0,
      approved: stats?.filter(r => r.status === 'approved').length || 0,
      paid: stats?.filter(r => r.status === 'paid').length || 0,
      rejected: stats?.filter(r => r.status === 'rejected').length || 0
    }

    return NextResponse.json({
      success: true,
      requests: requests || [],
      stats: statsData
    })

  } catch (error: any) {
    console.error('Admin payout requests error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}