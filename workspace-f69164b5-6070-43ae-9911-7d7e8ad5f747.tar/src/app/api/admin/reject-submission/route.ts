import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseServerClient } from '@/lib/supabaseClient'

export async function POST(request: NextRequest) {
  try {
    const { submissionId, reason } = await request.json()

    if (!submissionId) {
      return NextResponse.json({ 
        error: 'Missing required field: submissionId' 
      }, { status: 400 })
    }

    const supabase = createSupabaseServerClient()
    
    // Get user from session
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!profile?.is_admin) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Fetch the submission
    const { data: submission, error: submissionError } = await supabase
      .from('task_submissions')
      .select('*')
      .eq('id', submissionId)
      .single()

    if (submissionError || !submission) {
      return NextResponse.json({ error: 'Submission not found' }, { status: 404 })
    }

    if (submission.status !== 'pending') {
      return NextResponse.json({ 
        error: 'Submission has already been processed' 
      }, { status: 400 })
    }

    // Update submission status to rejected
    const { data: updatedSubmission, error: updateError } = await supabase
      .from('task_submissions')
      .update({
        status: 'rejected',
        reward_points: 0,
        reviewed_at: new Date().toISOString(),
        meta: {
          ...submission.meta,
          rejection_reason: reason,
          rejected_by: user.id,
          rejected_at: new Date().toISOString()
        }
      })
      .eq('id', submissionId)
      .select()
      .single()

    if (updateError) {
      console.error('Update submission error:', updateError)
      return NextResponse.json({ error: 'Failed to reject submission' }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      submission: {
        id: updatedSubmission.id,
        status: updatedSubmission.status,
        rejectionReason: reason
      }
    })

  } catch (error: any) {
    console.error('Reject submission error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}