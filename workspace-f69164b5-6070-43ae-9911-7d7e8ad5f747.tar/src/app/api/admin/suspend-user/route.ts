import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/utils/supabase/server'

export async function POST(request: NextRequest) {
  try {
    const { userId, reason } = await request.json()
    
    if (!userId || !reason) {
      return NextResponse.json({ 
        error: 'Missing required fields: userId, reason' 
      }, { status: 400 })
    }

    const supabase = createClient()
    
    // Get current admin user
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!profile?.is_admin) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Suspend the user using database function
    const { error: suspendError } = await supabase.rpc('suspend_user', {
      p_user_id: userId,
      p_reason: reason,
      p_suspended_by: user.id
    })

    if (suspendError) {
      console.error('Error suspending user:', suspendError)
      return NextResponse.json({ error: 'Failed to suspend user' }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: 'User suspended successfully'
    })

  } catch (error) {
    console.error('Suspend user error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}