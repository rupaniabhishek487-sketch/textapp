import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/utils/supabase/server'

export async function GET() {
  try {
    const supabase = createClient()
    
    // Get current user
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!profile?.is_admin) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Get gamification configuration
    const { data: config, error: configError } = await supabase.rpc('get_gamification_config')

    if (configError) {
      console.error('Error fetching gamification config:', configError)
      return NextResponse.json({ error: 'Failed to fetch gamification config' }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      config: config || []
    })

  } catch (error) {
    console.error('Gamification config error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const supabase = createClient()
    const { configKey, configValue, description } = await request.json()
    
    if (!configKey || configValue === undefined) {
      return NextResponse.json({ 
        error: 'Missing required fields: configKey, configValue' 
      }, { status: 400 })
    }

    // Get current user
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!profile?.is_admin) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Update configuration
    const { data, error } = await supabase
      .from('gamification_config')
      .upsert({
        config_key,
        config_value: configValue.toString(),
        description: description || '',
        updated_at: new Date().toISOString()
      })
      .select()
      .single()

    if (error) {
      console.error('Error updating gamification config:', error)
      return NextResponse.json({ error: 'Failed to update configuration' }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      config: data
    })

  } catch (error) {
    console.error('Gamification config update error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}