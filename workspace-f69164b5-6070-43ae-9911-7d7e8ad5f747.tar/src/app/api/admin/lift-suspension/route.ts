import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/utils/supabase/server'

export async function POST(request: NextRequest) {
  try {
    const { userId } = await request.json()
    
    if (!userId) {
      return NextResponse.json({ 
        error: 'Missing required field: userId' 
      }, { status: 400 })
    }

    const supabase = createClient()
    
    // Get current admin user
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!profile?.is_admin) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Lift the user suspension using database function
    const { error: liftError } = await supabase.rpc('lift_user_suspension', {
      p_user_id: userId
    })

    if (liftError) {
      console.error('Error lifting user suspension:', liftError)
      return NextResponse.json({ error: 'Failed to lift user suspension' }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: 'User suspension lifted successfully'
    })

  } catch (error) {
    console.error('Lift suspension error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}