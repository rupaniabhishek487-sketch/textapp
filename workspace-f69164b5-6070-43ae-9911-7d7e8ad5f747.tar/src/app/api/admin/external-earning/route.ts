import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/utils/supabase/server'

export async function GET() {
  try {
    const supabase = createClient()
    
    // Get current user
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!profile?.is_admin) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Get external offers (mock data for now)
    const mockOffers = [
      {
        id: '1',
        title: 'Daily Survey - Mobile Apps',
        description: 'Complete daily surveys and earn points from mobile app offers',
        reward_points: 50,
        partner_name: 'SurveyPro',
        offer_url: 'https://survey.example.com/offers',
        category: 'survey',
        active: true
      },
      {
        id: '2',
        title: 'Game Install - High Rewards',
        description: 'Install and play games to earn maximum points',
        reward_points: 100,
        partner_name: 'GameStudio',
        offer_url: 'https://games.example.com/offers',
        category: 'app_install',
        active: true
      },
      {
        id: '3',
        title: 'Video Ads - Entertainment',
        description: 'Watch entertaining video content and earn points',
        reward_points: 30,
        partner_name: 'VideoAdNetwork',
        offer_url: 'https://video.example.com/offers',
        category: 'video',
        active: true
      },
      {
        id: '4',
        title: 'Newsletter Signup',
        description: 'Subscribe to newsletters and earn instant bonus points',
        reward_points: 20,
        partner_name: 'Earnify',
        offer_url: '#',
        category: 'offerwall',
        active: true
      }
    ]

    return NextResponse.json({
      success: true,
      offers: mockOffers
    })

  } catch (error) {
      console.error('External offers error:', error)
      return NextResponse.json({ 
        error: 'Internal server error',
        details: error.message
      }, { status: 500 })
    }
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()
    const { id, title, description, reward_points, partner_name, offer_url, category, active, custom_config } = await request.json()
    
    if (!id || !title || !reward_points || !partner_name || !offer_url || !category) {
      return NextResponse.json({ 
        error: 'Missing required fields: id, title, reward_points, partner_name, offer_url, category, active' 
      }, { status: 400 })
    }

    // Get current user
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!profile?.is_admin) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Create new external offer
    const { data, error } = await supabase
      .from('external_offers')
      .insert({
        id: crypto.randomUUID(),
        title,
        description,
        reward_points,
        partner_name,
        offer_url,
        category,
        active,
        custom_config
      })
      .select()
      .single()

    if (error) {
      console.error('Failed to create external offer:', error)
      return NextResponse.json({ 
        error: 'Failed to create external offer',
        details: error.message
      }, { status: 500 })
    }

    console.log('External offer created:', { id, title, reward_points, partner_name, offer_url, category, active })

    return NextResponse.json({
      success: true,
      offer: {
        id,
        title,
        description,
        reward_points,
        partner_name,
        offer_url,
        category,
        active,
        custom_config
      }
    })

  } catch (error) {
      console.error('External offer creation error:', error)
      return NextResponse.json({ 
        error: 'Internal server error',
        details: error.message
      }, { status: 500 })
    }
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const supabase = createClient()
    const { id, active } = await request.json()
    
    if (!id) {
      return NextResponse.json({ 
        error: 'Missing required field: id' 
      }, { status: 400 })
    }

    // Get current user
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!profile?.is_admin) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Update external offer status
    const { data, error } = await supabase
      .from('external_offers')
      .update({
        id,
        active
      })
      .eq('id', id)
      .select()
      .single()

    if (error) {
      console.error('Failed to update external offer:', error)
      return NextResponse.json({ 
        error: 'Failed to update external offer',
        details: error.message
      }, { status: 500 })
    }

    console.log('External offer updated:', { id, active })

    return NextResponse.json({
      success: true,
      offer: {
        id,
        active
      }
    })

  } catch (error) {
      console.error('External offer update error:', error)
      return NextResponse.json({ 
        error: 'Internal server error',
        details: error.message
      }, { status: 500 })
    }
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const supabase = createClient()
    const { id } = await request.json()
    
    if (!id) {
      return NextResponse.json({ 
        error: 'Missing required field: id' 
      }, { status: 400 })
    }

    // Get current user
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!profile?.is_admin) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Delete external offer and related records
    const { data, error } = await supabase
      .from('external_offers')
      .delete()
      .eq('id', id)
      .select()
      .single()

    if (error) {
      console.error('Failed to delete external offer:', error)
      return NextResponse.json({ 
        error: 'Failed to delete external offer',
        details: error.message
      }, { status: 500 })
    }

    console.log('External offer deleted:', { id })

    return NextResponse.json({
      success: true,
      message: 'External offer and related records deleted successfully'
    })

  } catch (error) {
      console.error('External offer deletion error:', error)
      return NextResponse.json({ 
        error: 'Internal server error',
        details: error.message
      }, { status: 500 })
    }
  }
}