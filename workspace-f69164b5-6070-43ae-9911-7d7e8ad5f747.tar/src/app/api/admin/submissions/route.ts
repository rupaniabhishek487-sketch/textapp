import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseServerClient } from '@/lib/supabaseClient'

export async function GET(request: NextRequest) {
  try {
    const supabase = createSupabaseServerClient()
    
    // Get user from session
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!profile?.is_admin) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Fetch all submissions with task details
    const { data: submissions, error: submissionsError } = await supabase
      .from('task_submissions')
      .select(`
        *,
        tasks (
          id,
          title,
          task_type,
          reward_points
        ),
        profiles (
          display_name,
          phone
        )
      `)
      .order('created_at', { ascending: false })

    if (submissionsError) {
      console.error('Submissions error:', submissionsError)
      return NextResponse.json({ error: 'Failed to fetch submissions' }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      submissions: submissions || []
    })

  } catch (error: any) {
    console.error('Admin submissions error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}