import { createClient } from '@/utils/supabase/server'
import { cookies } from 'next/headers'
import { DeviceFingerprint } from '@/lib/device-fingerprint'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()
    const { fingerprint } = await request.json()
    
    if (!fingerprint) {
      return NextResponse.json({ error: 'Fingerprint is required' }, { status: 400 })
    }

    // Get current user
    const { data: { user }, error: userError } = await supabase.auth.getUser()
    
    if (userError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Get client IP and user agent
    const ipAddress = DeviceFingerprint.getClientIP(request)
    const userAgent = request.headers.get('user-agent') || ''

    // Record device fingerprint using RPC function
    const { error: recordError } = await supabase.rpc('record_device_fingerprint', {
      p_user_id: user.id,
      p_fingerprint_hash: fingerprint,
      p_ip_address: ipAddress,
      p_user_agent: userAgent
    })

    if (recordError) {
      console.error('Error recording device fingerprint:', recordError)
      return NextResponse.json({ error: 'Failed to record fingerprint' }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Device fingerprint error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}