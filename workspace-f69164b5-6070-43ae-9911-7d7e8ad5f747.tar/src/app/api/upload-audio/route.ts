import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseServerClient } from '@/lib/supabaseClient'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File
    const taskId = formData.get('taskId') as string

    if (!file || !taskId) {
      return NextResponse.json({ 
        error: 'Missing required fields: file, taskId' 
      }, { status: 400 })
    }

    // Validate file type
    const allowedTypes = ['audio/mpeg', 'audio/wav', 'audio/mp3', 'audio/m4a', 'audio/ogg']
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json({ 
        error: 'Invalid file type. Only audio files are allowed.' 
      }, { status: 400 })
    }

    // Validate file size (max 10MB)
    const maxSize = 10 * 1024 * 1024 // 10MB
    if (file.size > maxSize) {
      return NextResponse.json({ 
        error: 'File size too large. Maximum size is 10MB.' 
      }, { status: 400 })
    }

    const supabase = createSupabaseServerClient()
    
    // Get user from session
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Generate unique file name
    const fileExt = file.name.split('.').pop()
    const fileName = `${user.id}/${taskId}/${Date.now()}.${fileExt}`

    // Upload file to Supabase Storage
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('audio-submissions')
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: false
      })

    if (uploadError) {
      console.error('Upload error:', uploadError)
      return NextResponse.json({ 
        error: 'Failed to upload file' 
      }, { status: 500 })
    }

    // Get public URL
    const { data: urlData } = supabase.storage
      .from('audio-submissions')
      .getPublicUrl(fileName)

    // Enqueue verification job (you can implement this with a job queue)
    const verificationJob = await enqueueVerificationJob({
      submissionId: uploadData.path,
      audioUrl: urlData.publicUrl,
      userId: user.id,
      taskId: taskId
    })

    return NextResponse.json({
      success: true,
      fileUrl: urlData.publicUrl,
      fileName: uploadData.path,
      verificationJob: verificationJob
    })

  } catch (error: any) {
    console.error('Audio upload error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// Function to enqueue verification job
async function enqueueVerificationJob(jobData: {
  submissionId: string;
  audioUrl: string;
  userId: string;
  taskId: string;
}) {
  try {
    // This is a placeholder for job queue integration
    // You can use Bull Queue, Redis, or Supabase Edge Functions
    
    // For now, we'll create a simple record in a verification_jobs table
    const supabase = createSupabaseServerClient()
    
    const { data, error } = await supabase
      .from('verification_jobs')
      .insert({
        submission_id: jobData.submissionId,
        audio_url: jobData.audioUrl,
        user_id: jobData.userId,
        task_id: jobData.taskId,
        status: 'pending',
        created_at: new Date().toISOString()
      })
      .select()
      .single()

    if (error) {
      console.error('Job enqueue error:', error)
      return null
    }

    return {
      id: data.id,
      status: 'queued'
    }
  } catch (error) {
    console.error('Job enqueue error:', error)
    return null
  }
}