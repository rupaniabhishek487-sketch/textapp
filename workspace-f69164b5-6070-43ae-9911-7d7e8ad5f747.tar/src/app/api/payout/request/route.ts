import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseServerClient } from '@/lib/supabaseClient'
import { createRazorpayXPayout, RazorpayXPayoutRequest } from '@/lib/razorpayx'

export async function POST(request: NextRequest) {
  try {
    const { upiId, amount } = await request.json()

    if (!upiId || !amount) {
      return NextResponse.json({ 
        error: 'Missing required fields: upiId, amount' 
      }, { status: 400 })
    }

    const supabase = createSupabaseServerClient()
    
    // Get user from session
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is suspended
    const { data: isSuspended } = await supabase.rpc('is_user_suspended', {
      p_user_id: user.id
    })

    if (isSuspended) {
      return NextResponse.json({ error: 'Account suspended. You cannot request payouts.' }, { status: 403 })
    }

    // Check account age (48-hour hold for first payout)
    const { data: isPayoutEligible } = await supabase.rpc('is_payout_eligible', {
      p_user_id: user.id
    })

    if (!isPayoutEligible) {
      return NextResponse.json({ 
        error: 'Your account must be at least 48 hours old to withdraw.' 
      }, { status: 403 })
    }

    // Get configuration
    const pointsToInrRate = parseInt(process.env.POINTS_TO_INR_RATE || '100')
    const minPayoutThreshold = parseFloat(process.env.MIN_PAYOUT_THRESHOLD || '10')
    const maxPayoutAmount = parseFloat(process.env.MAX_PAYOUT_AMOUNT || '10000')
    const razorpayxEnabled = process.env.RAZORPAYX_ENABLED === 'true'

    // Validate amount
    if (amount < minPayoutThreshold) {
      return NextResponse.json({ 
        error: `Minimum payout amount is ₹${minPayoutThreshold}` 
      }, { status: 400 })
    }

    if (amount > maxPayoutAmount) {
      return NextResponse.json({ 
        error: `Maximum payout amount is ₹${maxPayoutAmount}` 
      }, { status: 400 })
    }

    // Validate UPI ID format
    const upiRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+$/
    if (!upiRegex.test(upiId)) {
      return NextResponse.json({ 
        error: 'Invalid UPI ID format' 
      }, { status: 400 })
    }

    // Get user's current balance
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('total_points, balance_inr')
      .eq('id', user.id)
      .single()

    if (profileError || !profile) {
      return NextResponse.json({ error: 'Failed to fetch user profile' }, { status: 500 })
    }

    // Check if user has sufficient balance
    if (amount > profile.balance_inr) {
      return NextResponse.json({ 
        error: 'Insufficient balance' 
      }, { status: 400 })
    }

    // Calculate points to be used
    const pointsToUse = Math.round(amount * pointsToInrRate)

    // Check if user has sufficient points
    if (pointsToUse > profile.total_points) {
      return NextResponse.json({ 
        error: 'Insufficient points' 
      }, { status: 400 })
    }

    // Check for existing pending payout requests
    const { data: existingRequests, error: existingError } = await supabase
      .from('payout_requests')
      .select('id')
      .eq('user_id', user.id)
      .in('status', ['pending', 'processing'])

    if (existingError) {
      console.error('Existing requests error:', existingError)
      return NextResponse.json({ error: 'Failed to check existing requests' }, { status: 500 })
    }

    if (existingRequests && existingRequests.length > 0) {
      return NextResponse.json({ 
        error: 'You already have a pending payout request' 
      }, { status: 400 })
    }

    // Create payout request (points are NOT deducted yet)
    const { data: payoutRequest, error: payoutError } = await supabase
      .from('payout_requests')
      .insert({
        user_id: user.id,
        amount_points: pointsToUse,
        amount_inr: amount,
        upi_id: upiId.trim(),
        status: 'pending',
        notes: `Auto-generated request for ₹${amount}`,
        meta: {
          requested_via: 'api',
          razorpayx_enabled: razorpayxEnabled,
          phase: razorpayxEnabled ? '2' : '1'
        }
      })
      .select()
      .single()

    if (payoutError) {
      console.error('Payout request error:', payoutError)
      return NextResponse.json({ error: 'Failed to create payout request' }, { status: 500 })
    }

    // Phase 2: Create RazorpayX payout if enabled
    let razorpayXPayoutId = null
    if (razorpayxEnabled) {
      try {
        const razorpayXRequest: RazorpayXPayoutRequest = {
          account_number: process.env.RAZORPAYX_ACCOUNT_NUMBER!,
          fund_account_id: process.env.RAZORPAYX_FUND_ACCOUNT_ID!,
          amount: Math.round(amount * 100), // RazorpayX expects amount in paise
          currency: 'INR',
          mode: 'IMPS',
          purpose: 'Payout to Earnify user',
          queue_if_low_balance: true,
          reference_id: payoutRequest.id,
          narration: `Earnify payout for ${user.id}`,
          notes: {
            user_id: user.id,
            payout_request_id: payoutRequest.id,
            upi_id: upiId
          }
        }

        const razorpayXResponse = await createRazorpayXPayout(razorpayXRequest)
        razorpayXPayoutId = razorpayXResponse.id

        // Update payout request with RazorpayX details
        await supabase
          .from('payout_requests')
          .update({
            razorpay_payout_id: razorpayXPayoutId,
            meta: {
              ...payoutRequest.meta,
              razorpayx_response: razorpayXResponse
            }
          })
          .eq('id', payoutRequest.id)

      } catch (error) {
        console.error('RazorpayX error:', error)
        // Continue without RazorpayX if it fails
      }
    }

    return NextResponse.json({
      success: true,
      request: {
        id: payoutRequest.id,
        amount_inr: payoutRequest.amount_inr,
        points_used: payoutRequest.amount_points,
        status: payoutRequest.status,
        upi_id: payoutRequest.upi_id,
        razorpayx_payout_id: razorpayXPayoutId,
        phase: razorpayxEnabled ? '2' : '1',
        message: razorpayxEnabled 
          ? 'Payout request created and queued for processing via RazorpayX'
          : 'Payout request created successfully. Points will be deducted upon admin approval.'
      }
    })

  } catch (error: any) {
    console.error('Request payout error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}