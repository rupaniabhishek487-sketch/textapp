import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseServerClient } from '@/lib/supabaseClient'

export async function GET(request: NextRequest) {
  try {
    const supabase = createSupabaseServerClient()
    
    // Get user from session
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Get user's payout requests
    const { data: requests, error: requestsError } = await supabase
      .from('payout_requests')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })

    if (requestsError) {
      console.error('Payout requests error:', requestsError)
      return NextResponse.json({ error: 'Failed to fetch payout requests' }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      requests: requests || []
    })

  } catch (error: any) {
    console.error('Get payout requests error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}