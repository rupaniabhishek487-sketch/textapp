import { NextRequest, NextResponse } from "next/server"
import { createSupabaseServerClient } from "@/lib/supabaseClient"
import { RateLimiter, RATE_LIMITS } from "@/lib/rate-limiter"

export async function POST(request: NextRequest) {
  try {
    const { taskId, submissionText, submissionUrl, similarityScore } = await request.json()

    if (!taskId) {
      return NextResponse.json(
        { error: "Missing required field: taskId" },
        { status: 400 }
      )
    }

    const supabase = createSupabaseServerClient()
    
    // Get user from session
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is suspended
    const { data: isSuspended } = await supabase.rpc('is_user_suspended', {
      p_user_id: user.id
    })

    if (isSuspended) {
      return NextResponse.json({ error: 'Account suspended. You cannot submit tasks.' }, { status: 403 })
    }

    // Get task details
    const { data: task, error: taskError } = await supabase
      .from('tasks')
      .select('*')
      .eq('id', taskId)
      .single()

    if (taskError || !task) {
      return NextResponse.json(
        { error: "Task not found" },
        { status: 404 }
      )
    }

    // Apply rate limiting based on task type
    const rateLimitConfig = task.task_type === 'transcription' 
      ? RATE_LIMITS.AUDIO_SUBMISSION 
      : RATE_LIMITS.TEXT_SUBMISSION

    const rateLimitResult = await RateLimiter.checkRateLimit(user.id, rateLimitConfig)
    if (!rateLimitResult.allowed) {
      return NextResponse.json({ error: rateLimitResult.error }, { status: 429 })
    }

    // Check daily limit
    const dailyLimitResult = await RateLimiter.checkDailyLimit(user.id)
    if (!dailyLimitResult.allowed) {
      return NextResponse.json({ error: dailyLimitResult.error }, { status: 429 })
    }

    // Calculate similarity score for typing tasks
    let finalSimilarityScore = similarityScore || 0
    let status: 'pending' | 'approved' | 'rejected' = 'pending'

    if (task.task_type === 'typing' && submissionText) {
      // Use client-provided similarity score
      finalSimilarityScore = similarityScore || 0
      
      // Auto-approve if similarity >= 90%
      status = finalSimilarityScore >= 0.90 ? 'approved' : 'rejected'
    } else if (task.task_type === 'transcription') {
      // Transcription tasks typically need manual review
      status = 'pending'
      finalSimilarityScore = 0 // Will be set during manual review
    }

    // Create submission
    const { data: submission, error: submissionError } = await supabase
      .from('task_submissions')
      .insert({
        task_id: taskId,
        user_id: user.id,
        submission_text: submissionText,
        submission_url: submissionUrl,
        auto_score: finalSimilarityScore,
        status: status,
        reward_points: status === 'approved' ? task.reward_points : 0,
        submitted_at: new Date().toISOString()
      })
      .select()
      .single()

    if (submissionError) {
      throw submissionError
    }

    // Record the rate limit attempt
    const actionType = task.task_type === 'transcription' ? 'audio_submission' : 'text_submission'
    await RateLimiter.recordAttempt(user.id, actionType, {
      task_id: taskId,
      task_type: task.task_type,
      submission_id: submission.id
    })

    // If approved, create transaction and update profile
    let pointsAwarded = 0
    if (status === 'approved') {
      pointsAwarded = task.reward_points
      
      // Create transaction
      await supabase
        .from('transactions')
        .insert({
          user_id: user.id,
          kind: 'task_reward',
          points: pointsAwarded,
          inr_value: pointsAwarded * 0.01, // 1 point = ₹0.01
          meta: {
            task_id: taskId,
            task_title: task.title,
            similarity_score: finalSimilarityScore
          }
        })

      // Update profile
      await supabase
        .from('profiles')
        .update({
          total_points: supabase.rpc('increment', { x: pointsAwarded }),
          balance_inr: supabase.rpc('increment', { x: pointsAwarded * 0.01 }),
          total_tasks_completed: supabase.rpc('increment', { x: 1 }),
          total_earnings_inr: supabase.rpc('increment', { x: pointsAwarded * 0.01 }),
          total_earned_points: supabase.rpc('increment', { x: pointsAwarded })
        })
        .eq('id', user.id)

      // Update user level and award badges
      try {
        await supabase.rpc('update_user_level_and_badges', {
          p_user_id: user.id
        })
      } catch (error) {
        console.error('Failed to update user level and badges:', error)
      }
    }

    return NextResponse.json({
      success: true,
      submission: {
        id: submission.id,
        status: status,
        similarityScore: finalSimilarityScore,
        pointsAwarded: pointsAwarded
      }
    })

  } catch (error) {
    console.error("Submit task error:", error)
    return NextResponse.json(
      { error: "Failed to submit task" },
      { status: 500 }
    )
  }
}

function calculateSimilarity(text1: string, text2: string): number {
  const normalize = (str: string) => str.toLowerCase().replace(/\s+/g, ' ').trim()
  const normalized1 = normalize(text1)
  const normalized2 = normalize(text2)
  
  const longer = normalized1.length > normalized2.length ? normalized1 : normalized2
  const shorter = normalized1.length > normalized2.length ? normalized2 : normalized1
  
  if (longer.length === 0) return 100.0
  
  const editDistance = levenshteinDistance(longer, shorter)
  return ((longer.length - editDistance) / longer.length) * 100
}

function levenshteinDistance(str1: string, str2: string): number {
  const matrix = []
  
  for (let i = 0; i <= str2.length; i++) {
    matrix[i] = [i]
  }
  
  for (let j = 1; j <= str1.length; j++) {
    matrix[0][j] = j
  }
  
  for (let i = 1; i <= str1.length; i++) {
    for (let j = 1; j <= str2.length; j++) {
      if (str2.charAt(j - 1) === str1.charAt(i - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1]
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j - 1] + 1
        )
      }
    }
  }
  
  return matrix[str1.length][str2.length]
}