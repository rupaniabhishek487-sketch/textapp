import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseServerClient } from '@/lib/supabaseClient'

export async function GET(request: NextRequest) {
  try {
    const supabase = createSupabaseServerClient()
    
    // Get user from session
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Get user statistics
    const { data: stats, error: statsError } = await supabase.rpc('get_user_stats', {
      p_user_id: user.id
    })

    if (statsError) {
      console.error('Stats error:', statsError)
      return NextResponse.json({ error: 'Failed to fetch wallet stats' }, { status: 500 })
    }

    // Get pending payouts count
    const { data: pendingPayouts, error: pendingError } = await supabase
      .from('payout_requests')
      .select('id')
      .eq('user_id', user.id)
      .in('status', ['pending', 'processing'])

    if (pendingError) {
      console.error('Pending payouts error:', pendingError)
      return NextResponse.json({ error: 'Failed to fetch pending payouts' }, { status: 500 })
    }

    const walletStats = stats[0] || {}

    return NextResponse.json({
      success: true,
      stats: {
        total_points: walletStats.total_points || 0,
        balance_inr: walletStats.balance_inr || 0,
        total_earnings_inr: walletStats.total_earnings_inr || 0,
        total_tasks_completed: walletStats.total_tasks_completed || 0,
        pending_payouts: pendingPayouts?.length || 0
      }
    })

  } catch (error: any) {
    console.error('Wallet stats error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}