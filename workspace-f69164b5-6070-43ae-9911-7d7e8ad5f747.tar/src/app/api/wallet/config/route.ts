import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseServerClient } from '@/lib/supabaseClient'

export async function GET(request: NextRequest) {
  try {
    const supabase = createSupabaseServerClient()
    
    // Get user from session
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Get configuration from system_config table or environment variables
    const config = {
      points_to_inr_rate: parseInt(process.env.POINTS_TO_INR_RATE || '100'), // 100 points = ₹1
      min_payout_threshold: parseFloat(process.env.MIN_PAYOUT_THRESHOLD || '10'), // ₹10 minimum
      max_payout_amount: parseFloat(process.env.MAX_PAYOUT_AMOUNT || '10000'), // ₹10,000 maximum
      payout_processing_time: process.env.PAYOUT_PROCESSING_TIME || '2-3 business days',
      payout_methods: ['UPI Transfer'], // Phase 1: Manual UPI only
      razorpayx_enabled: process.env.RAZORPAYX_ENABLED === 'true', // Phase 2 feature flag
      manual_payout_instructions: {
        title: 'Manual Payout Process (Phase 1)',
        description: 'Currently, all payouts are processed manually by our team.',
        steps: [
          'Submit your payout request with correct UPI ID',
          'Our team will review and approve your request',
          'Approved payouts are processed within 2-3 business days',
          'You will receive the amount directly to your UPI ID'
        ],
        support: 'For payout issues, contact support@earnify.com'
      }
    }

    return NextResponse.json({
      success: true,
      config
    })

  } catch (error: any) {
    console.error('Wallet config error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}