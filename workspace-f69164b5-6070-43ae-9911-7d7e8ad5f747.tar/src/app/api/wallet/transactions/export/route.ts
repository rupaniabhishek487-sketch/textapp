import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseServerClient } from '@/lib/supabaseClient'

export async function GET(request: NextRequest) {
  try {
    const supabase = createSupabaseServerClient()
    
    // Get user from session
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Get all transactions for export
    const { data: transactions, error: transactionsError } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })

    if (transactionsError) {
      console.error('Export transactions error:', transactionsError)
      return NextResponse.json({ error: 'Failed to export transactions' }, { status: 500 })
    }

    // Generate CSV content
    const headers = ['Date', 'Type', 'Points', 'Amount (₹)', 'Status', 'Description']
    const rows = transactions.map(transaction => [
      new Date(transaction.created_at).toLocaleDateString(),
      transaction.kind,
      transaction.points.toString(),
      transaction.inr_value.toFixed(2),
      transaction.status,
      transaction.meta?.task_title || transaction.meta?.description || '-'
    ])

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n')

    // Return CSV as response
    return new NextResponse(csvContent, {
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': `attachment; filename="transaction-history-${new Date().toISOString().split('T')[0]}.csv"`
      }
    })

  } catch (error: any) {
    console.error('Export transactions error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}