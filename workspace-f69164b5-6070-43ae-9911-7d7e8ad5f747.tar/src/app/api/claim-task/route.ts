import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseServerClient } from '@/lib/supabaseClient'

export async function POST(request: NextRequest) {
  try {
    const { taskId } = await request.json()
    
    if (!taskId) {
      return NextResponse.json({ error: 'Task ID is required' }, { status: 400 })
    }

    const supabase = createSupabaseServerClient()
    
    // Get user from session
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is suspended
    const { data: isSuspended } = await supabase.rpc('is_user_suspended', {
      p_user_id: user.id
    })

    if (isSuspended) {
      return NextResponse.json({ error: 'Account suspended. You cannot claim tasks.' }, { status: 403 })
    }

    // Check if task exists and is available
    const { data: task, error: taskError } = await supabase
      .from('tasks')
      .select('*')
      .eq('id', taskId)
      .eq('active', true)
      .single()

    if (taskError || !task) {
      return NextResponse.json({ error: 'Task not found or inactive' }, { status: 404 })
    }

    // Check if user already claimed this task
    const { data: existingSubmission, error: existingError } = await supabase
      .from('task_submissions')
      .select('*')
      .eq('task_id', taskId)
      .eq('user_id', user.id)
      .single()

    if (existingError && existingError.code !== 'PGRST116') {
      return NextResponse.json({ error: 'Database error' }, { status: 500 })
    }

    if (existingSubmission) {
      return NextResponse.json({ error: 'Task already claimed or submitted' }, { status: 409 })
    }

    // Create task submission with 'claimed' status
    const { data: submission, error: submissionError } = await supabase
      .from('task_submissions')
      .insert({
        task_id: taskId,
        user_id: user.id,
        status: 'claimed',
        claimed_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + 30 * 60 * 1000).toISOString() // 30 minutes expiry
      })
      .select()
      .single()

    if (submissionError) {
      console.error('Submission error:', submissionError)
      return NextResponse.json({ error: 'Failed to claim task' }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      submission: {
        id: submission.id,
        task_id: submission.task_id,
        status: submission.status,
        expires_at: submission.expires_at
      }
    })

  } catch (error: any) {
    console.error('Claim task error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}