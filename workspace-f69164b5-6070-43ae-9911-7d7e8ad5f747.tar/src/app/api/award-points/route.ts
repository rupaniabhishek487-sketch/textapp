import { NextRequest, NextResponse } from 'next/server'
import { createSupabaseServerClient } from '@/lib/supabaseClient'

export async function POST(request: NextRequest) {
  try {
    const { userId, points, kind, metadata } = await request.json()

    if (!userId || points === undefined || !kind) {
      return NextResponse.json({ 
        error: 'Missing required fields: userId, points, kind' 
      }, { status: 400 })
    }

    const supabase = createSupabaseServerClient()
    
    // Get user from session (for admin verification)
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check if user is admin or awarding points to self
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    const isAdmin = profile?.is_admin || false
    const isSelfAward = user.id === userId

    if (!isAdmin && !isSelfAward) {
      return NextResponse.json({ error: 'Cannot award points to other users' }, { status: 403 })
    }

    // Validate points amount
    if (points <= 0) {
      return NextResponse.json({ error: 'Points must be positive' }, { status: 400 })
    }

    // Validate kind
    const validKinds = ['task_reward', 'referral_bonus', 'payout', 'adjustment', 'bonus']
    if (!validKinds.includes(kind)) {
      return NextResponse.json({ error: 'Invalid transaction kind' }, { status: 400 })
    }

    // Award points atomically
    const result = await awardPointsAtomically(
      supabase,
      userId,
      points,
      kind,
      metadata || {}
    )

    if (!result.success) {
      return NextResponse.json({ 
        error: result.error || 'Failed to award points' 
      }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      pointsAwarded: points,
      userId,
      kind
    })

  } catch (error: any) {
    console.error('Award points error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// Atomic function to award points
async function awardPointsAtomically(
  supabase: any,
  userId: string,
  points: number,
  kind: string,
  metadata: any
): Promise<{ success: boolean; error?: string }> {
  try {
    // Calculate INR value (1 point = ₹0.01)
    const inrValue = points * 0.01

    // Use a database function to ensure atomicity
    const { data, error } = await supabase.rpc('award_points_transaction', {
      p_user_id: userId,
      p_points: points,
      p_inr_value: inrValue,
      p_kind: kind,
      p_metadata: metadata
    })

    if (error) {
      console.error('Award points transaction error:', error)
      return { success: false, error: error.message }
    }

    return { success: true, data }
  } catch (error: any) {
    console.error('Award points error:', error)
    return { success: false, error: error.message }
  }
}