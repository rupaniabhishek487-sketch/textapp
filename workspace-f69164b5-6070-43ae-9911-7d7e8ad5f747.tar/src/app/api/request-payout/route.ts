import { NextRequest, NextResponse } from "next/server"
import { createSupabaseServerClient } from "@/lib/supabaseClient"

const POINTS_TO_INR_RATE = 0.01 // 1 point = ₹0.01
const MIN_PAYOUT_POINTS = 1000 // Minimum 1000 points for payout

export async function POST(request: NextRequest) {
  try {
    const { userId, amountPoints, upiId } = await request.json()

    if (!userId || !amountPoints || !upiId) {
      return NextResponse.json(
        { error: "Missing required fields: userId, amountPoints, upiId" },
        { status: 400 }
      )
    }

    const points = parseInt(amountPoints)
    
    if (points < MIN_PAYOUT_POINTS) {
      return NextResponse.json(
        { error: `Minimum ${MIN_PAYOUT_POINTS} points required for payout` },
        { status: 400 }
      )
    }

    // Get user profile to check balance
    const supabase = createSupabaseServerClient()
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('points, balance_inr')
      .eq('id', userId)
      .single()

    if (profileError || !profile) {
      return NextResponse.json(
        { error: "User profile not found" },
        { status: 404 }
      )
    }

    if (profile.points < points) {
      return NextResponse.json(
        { error: "Insufficient points balance" },
        { status: 400 }
      )
    }

    const inrAmount = points * POINTS_TO_INR_RATE

    // Create payout request
    const { data: payoutRequest, error: payoutError } = await supabase
      .from('payout_requests')
      .insert({
        user_id: userId,
        amount_points: points,
        amount_inr: inrAmount,
        upi_id: upiId.trim(),
        status: 'pending'
      })
      .select()
      .single()

    if (payoutError) {
      throw payoutError
    }

    return NextResponse.json({
      success: true,
      payoutRequest: {
        id: payoutRequest.id,
        amountPoints: points,
        amountInr: inrAmount,
        upiId: upiId.trim(),
        status: 'pending',
        createdAt: payoutRequest.created_at
      }
    })

  } catch (error) {
    console.error("Request payout error:", error)
    return NextResponse.json(
      { error: "Failed to request payout" },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: "userId parameter is required" },
        { status: 400 }
      )
    }

    // Get user's payout requests
    const { data: payoutRequests, error } = await supabase
      .from('payout_requests')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })

    if (error) {
      throw error
    }

    return NextResponse.json({
      success: true,
      payoutRequests: payoutRequests || []
    })

  } catch (error) {
    console.error("Get payout requests error:", error)
    return NextResponse.json(
      { error: "Failed to fetch payout requests" },
      { status: 500 }
    )
  }
}