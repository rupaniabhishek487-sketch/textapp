import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/utils/supabase/server'

export async function GET() {
  try {
    const supabase = createClient()
    
    // Get current user
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Get user gamification stats
    const { data: stats, error: statsError } = await supabase.rpc('get_user_gamification_stats', {
      p_user_id: user.id
    })

    if (statsError) {
      console.error('Error fetching gamification stats:', statsError)
      return NextResponse.json({ error: 'Failed to fetch gamification stats' }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      stats: stats?.[0] || null
    })

  } catch (error) {
    console.error('Gamification stats error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}