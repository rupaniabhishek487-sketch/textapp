import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/utils/supabase/server'

export async function GET() {
  try {
    const supabase = createClient()
    
    // Get current user
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Get user badges
    const { data: badges, error: badgesError } = await supabase
      .from('user_badges')
      .select('*')
      .eq('user_id', user.id)
      .eq('is_active', true)
      .order('earned_at', { ascending: true })

    if (badgesError) {
      console.error('Error fetching badges:', badgesError)
      return NextResponse.json({ error: 'Failed to fetch badges' }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      badges: badges || []
    })

  } catch (error) {
    console.error('Badges error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}