import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/utils/supabase/server'

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()
    const { offer_id, action, user_agent } = await request.json()
    
    if (!offer_id || !action) {
      return NextResponse.json({ 
        error: 'Missing required fields: offer_id, action' 
      }, { status: 400 })
    }

    // Get current user
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Get offer details (in real implementation, this would come from database)
    const mockOffers: { [key: string]: any } = {
      '1': { title: 'Complete Daily Survey', reward_points: 50 },
      '2': { title: 'Download New Game', reward_points: 100 },
      '3': { title: 'Watch Product Demo', reward_points: 25 },
      '4': { title: 'Sign Up for Newsletter', reward_points: 20 },
      '5': { title: 'Complete Profile Setup', reward_points: 30 },
      '6': { title: 'Refer a Friend', reward_points: 75 },
      '7': { title: 'Daily Check-in Bonus', reward_points: 15 }
    }

    const offer = mockOffers[offer_id]
    
    if (!offer) {
      return NextResponse.json({ error: 'Offer not found' }, { status: 404 })
    }

    // Log the offer interaction
    console.log(`Offer ${action}:`, {
      offer_id,
      user_id: user.id,
      user_agent,
      timestamp: new Date().toISOString(),
      offer_details: offer
    })

    // Simulate different actions
    let message = ''
    let awardPoints = 0
    
    switch (action) {
      case 'click':
        message = 'Offer tracking initiated'
        break
      case 'start':
        message = 'Offer started successfully'
        break
      case 'complete':
        message = 'Offer completed successfully'
        awardPoints = offer.reward_points
        break
      case 'verify':
        message = 'Offer verification completed'
        awardPoints = offer.reward_points
        break
      default:
        message = 'Unknown action'
        break
    }

    // Award points if completion
    if (awardPoints > 0) {
      try {
        // Create transaction for offer completion
        await supabase
          .from('transactions')
          .insert({
            user_id: user.id,
            kind: 'bonus',
            points: awardPoints,
            inr_value: awardPoints * 0.01, // 1 point = ₹0.01
            meta: {
              type: 'external_offer',
              offer_id: offer_id,
              offer_title: offer.title,
              action: action,
              user_agent: user_agent
            },
            status: 'completed'
          })

        // Update user points
        await supabase
          .from('profiles')
          .update({
            total_points: supabase.rpc('increment', { x: awardPoints }),
            balance_inr: supabase.rpc('increment', { x: awardPoints * 0.01 }),
            total_earned_points: supabase.rpc('increment', { x: awardPoints }),
            total_earnings_inr: supabase.rpc('increment', { x: awardPoints * 0.01 })
          })
          .eq('id', user.id)

        console.log(`Awarded ${awardPoints} points for offer ${action}: ${offer.title}`)
      } catch (error) {
        console.error('Failed to award points:', error)
      }
    }

    return NextResponse.json({
      success: true,
      message,
      points_awarded: awardPoints,
      offer_details: {
        id: offer_id,
        title: offer.title,
        reward_points: offer.reward_points,
        action: action
      }
    })

  } catch (error) {
    console.error('Offer callback error:', error)
    return NextResponse.json({ 
      error: 'Internal server error',
      details: error.message
    }, { status: 500 })
  }
}