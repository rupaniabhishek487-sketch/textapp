'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { useToast } from '@/hooks/use-toast'
import { 
  Play, 
  Pause, 
  PlayCircle, 
  CheckCircle, 
  Clock, 
  Eye, 
  ExternalLink,
  Award,
  AlertCircle,
  Volume2
} from 'lucide-react'

interface VideoOffer {
  id: string
  title: string
  description: string
  reward_points: number
  video_url?: string
  duration: number
  category: 'gaming' | 'entertainment' | 'educational' | 'news' | 'lifestyle'
  partner_name: string
  thumbnail_url?: string
  active: boolean
}

export default function WatchAdsPage() {
  const { toast } = useToast()
  const [videos, setVideos] = useState<VideoOffer[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [watchingVideo, setWatchingVideo] = useState<VideoOffer | null>(null)
  const [videoProgress, setVideoProgress] = useState(0)
  const [countdown, setCountdown] = useState<number | null>(null)

  useEffect(() => {
    fetchVideos()
  }, [])

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null
    
    if (countdown && countdown > 0) {
      interval = setInterval(() => {
        setCountdown(prev => {
          if (prev === null || prev <= 1) {
            clearInterval(interval!)
            setVideoProgress(100)
            handleVideoComplete()
            return null
          }
          return prev - 1
        })
      }, 1000)
    }
    
    return () => {
      if (interval) clearInterval(interval)
    }
  }, [countdown])

  const fetchVideos = async () => {
    try {
      // Mock video data - in real implementation, this would come from video ad network
      const mockVideos: VideoOffer[] = [
        {
          id: '1',
          title: 'Watch Mobile Game Trailer',
          description: 'Watch the exciting trailer for our new mobile game and earn points',
          reward_points: 30,
          video_url: 'https://example.com/trailer1.mp4',
          duration: 30,
          category: 'gaming',
          partner_name: 'GameStudio',
          thumbnail_url: 'https://example.com/thumb1.jpg',
          active: true
        },
        {
          id: '2',
          title: 'Product Demo Video',
          description: 'Watch this 2-minute product demonstration and learn about new features',
          reward_points: 50,
          video_url: 'https://example.com/demo2.mp4',
          duration: 120,
          category: 'entertainment',
          partner_name: 'BrandX',
          thumbnail_url: 'https://example.com/thumb2.jpg',
          active: true
        },
        {
          id: '3',
          title: 'Educational Content',
          description: 'Learn something new and valuable in just 5 minutes',
          reward_points: 25,
          video_url: 'https://example.com/edu3.mp4',
          duration: 300,
          category: 'educational',
          partner_name: 'EduPro',
          thumbnail_url: 'https://example.com/thumb3.jpg',
          active: true
        },
        {
          id: '4',
          title: 'News Update',
          description: 'Stay informed with the latest news and current events',
          reward_points: 15,
          video_url: 'https://example.com/news4.mp4',
          duration: 60,
          category: 'news',
          partner_name: 'NewsNetwork',
          thumbnail_url: 'https://example.com/thumb4.jpg',
          active: true
        },
        {
          id: '5',
          title: 'Lifestyle Tips',
          description: 'Discover lifestyle tips and tricks to improve your daily life',
          reward_points: 20,
          video_url: 'https://example.com/lifestyle5.mp4',
          duration: 90,
          category: 'lifestyle',
          partner_name: 'LifeStyleCo',
          thumbnail_url: 'https://example.com/thumb5.jpg',
          active: false
        }
      ]

      setVideos(mockVideos)
      setLoading(false)
    } catch (error) {
      console.error('Failed to fetch videos:', error)
      toast({
        title: "Error",
        description: "Failed to load videos",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const filteredVideos = videos.filter(video => {
    if (selectedCategory === 'all') return true
    return video.category === selectedCategory
  })

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      gaming: 'bg-red-100 text-red-800',
      entertainment: 'bg-purple-100 text-purple-800',
      educational: 'bg-blue-100 text-blue-800',
      news: 'bg-green-100 text-green-800',
      lifestyle: 'bg-yellow-100 text-yellow-800',
      all: 'bg-gray-100 text-gray-800'
    }
    return colors[category] || 'bg-gray-100 text-gray-800'
  }

  const handleVideoStart = async (video: VideoOffer) => {
    setWatchingVideo(video)
    setVideoProgress(0)
    setCountdown(video.duration)
    
    // Track video start
    try {
      const response = await fetch('/api/offers/callback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          offer_id: video.id,
          action: 'start',
          user_agent: navigator.userAgent
        })
      })

      if (response.ok) {
        const data = await response.json()
        toast({
          title: "Video Started",
          description: data.message || "Video tracking initiated",
        })
      } else {
        toast({
          title: "Video Failed",
          description: "Failed to start video",
          variant: "destructive"
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to start video",
        variant: "destructive"
      })
    }
  }

  const handleVideoComplete = async () => {
    if (!watchingVideo) return
    
    try {
      const response = await fetch('/api/offers/callback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          offer_id: watchingVideo.id,
          action: 'complete',
          user_agent: navigator.userAgent
        })
      })

      if (response.ok) {
        const data = await response.json()
        toast({
          title: "Video Completed!",
          description: `Earned ${watchingVideo.reward_points} points!`,
        })
        
        // Reset video state
        setWatchingVideo(null)
        setVideoProgress(100)
        setCountdown(null)
      } else {
        toast({
          title: "Video Completion Failed",
          description: "Failed to complete video",
          variant: "destructive"
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to complete video",
        variant: "destructive"
      })
    }
  }

  const categories = [
    { id: 'all', name: 'All Videos', icon: 'Grid3X3' },
    { id: 'gaming', name: 'Gaming', icon: 'Gamepad2' },
    { id: 'entertainment', name: 'Entertainment', icon: 'Play' },
    { id: 'educational', name: 'Educational', icon: 'BookOpen' },
    { id: 'news', name: 'News', icon: 'Newspaper' },
    { id: 'lifestyle', name: 'Lifestyle', icon: 'Heart' }
  ]

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2">Watch Ads</h1>
          <p className="text-muted-foreground">
            Watch videos and earn points instantly
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Available Videos</CardTitle>
              <Play className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{videos.length}</div>
              <p className="text-xs text-muted-foreground">
                Active videos available now
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Potential</CardTitle>
              <Award className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">150</div>
              <p className="text-xs text-muted-foreground">
                Potential points from videos
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completed Today</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3</div>
              <p className="text-xs text-muted-foreground">
                Videos completed today
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Category Filter */}
        <Card>
          <CardHeader>
            <CardTitle>Categories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category.id)}
                  className="flex items-center gap-2"
                >
                  <category.icon className="h-4 w-4" />
                  <span>{category.name}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Video Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVideos.map((video) => (
            <Card key={video.id} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader className="relative">
                {video.thumbnail_url && (
                  <div className="absolute inset-0 z-10">
                    <img 
                      src={video.thumbnail_url} 
                      alt={video.title}
                      className="w-full h-48 object-cover"
                    />
                    <div className="absolute top-2 right-2">
                      <Badge className="bg-red-100 text-red-800">
                        <Volume2 className="h-3 w-3 mr-1" />
                        {video.duration}s
                      </Badge>
                    </div>
                  </div>
                )}
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getCategoryColor(video.category)}`}>
                        <Play className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">{video.title}</h3>
                        <p className="text-sm text-muted-foreground">{video.description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-purple-600">+{video.reward_points}</div>
                      <p className="text-xs text-muted-foreground">points</p>
                    </div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  <span>{video.duration}s</span>
                  <span className="mx-2">•</span>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(video.category)}`}>
                    {video.category.charAt(0).toUpperCase()}
                  </div>
                </div>
                
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <Eye className="h-4 w-4" />
                  <span>{video.partner_name}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <Button 
                    onClick={() => handleVideoStart(video)}
                    className="w-full"
                    disabled={!video.active || watchingVideo?.id === video.id}
                  >
                    {watchingVideo?.id === video.id ? (
                      <>
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </>
                    ) : (
                      <>
                        <PlayCircle className="h-4 w-4 mr-2" />
                        Watch Video
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Video Player Modal */}
        {watchingVideo && (
          <div className="fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center">
            <div className="bg-white rounded-lg p-6 max-w-4xl mx-auto">
              <div className="text-center mb-4">
                <h3 className="text-xl font-bold text-white mb-2">
                  Watching: {watchingVideo.title}
                </h3>
              </div>
              
              <div className="relative w-full">
                <div className="aspect-video bg-black rounded-lg overflow-hidden">
                  {/* Simulated video player */}
                  <div className="flex items-center justify-center h-full">
                    <div className="text-white text-center">
                      <PlayCircle className="h-16 w-16 mb-4" />
                      <p className="text-lg">Video Player</p>
                      <p className="text-sm text-gray-400">
                        {watchingVideo.video_url}
                      </p>
                    </div>
                  </div>
                  
                  {/* Progress bar */}
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <div className="mb-2">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-white font-medium">Progress</span>
                        <span className="text-white">
                          {countdown !== null ? `${Math.floor((video.duration - countdown) / video.duration * 100)}%` : '100%'}
                        </span>
                      </div>
                      </div>
                      <Progress value={videoProgress} className="h-2" />
                    </div>
                    
                    <div className="text-center">
                      {countdown !== null && (
                        <span className="text-white font-bold">
                          {Math.ceil(countdown / 60)}:{String(countdown % 60).padStart(2, '0')}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex justify-between mt-4">
              <Button 
                variant="outline"
                onClick={() => {
                  setWatchingVideo(null)
                  setVideoProgress(0)
                  setCountdown(null)
                }}
                className="text-white"
              >
                Close
              </Button>
            </div>
          </div>
        </div>
        )}

        {/* Info Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-yellow-600" />
              How It Works
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <h4 className="font-semibold">Watch & Earn</h4>
              <p className="text-sm text-muted-foreground">
                Watch videos from our partners and earn points instantly.
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold">Tracked Viewing</h4>
              <p className="text-sm text-muted-foreground">
                Your video progress is tracked and points are awarded upon completion.
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold">Rewarded Points</h4>
              <p className="text-sm text-muted-foreground">
                Points are automatically credited to your account when videos are completed.
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold">Safe & Secure</h4>
              <p className="text-sm text-muted-foreground">
                All video content is moderated and from trusted partners.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}