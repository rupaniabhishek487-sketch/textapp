"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from '@/components/ui/pagination'
import { useToast } from '@/hooks/use-toast'
import { useAuth } from '@/components/AuthProvider'
import { 
  Wallet, 
  TrendingUp, 
  ArrowUpRight, 
  History, 
  Download,
  RefreshCw,
  Info,
  Calendar,
  IndianRupee,
  Coins,
  ArrowDownRight,
  ArrowUpLeft
} from 'lucide-react'
import { Transaction } from '@/types/supabase'

interface WalletStats {
  total_points: number
  balance_inr: number
  total_earnings_inr: number
  total_tasks_completed: number
  pending_payouts: number
}

interface Config {
  points_to_inr_rate: number
  min_payout_threshold: number
  max_payout_amount: number
}

export default function WalletPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState<WalletStats | null>(null)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [config, setConfig] = useState<Config | null>(null)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [pageSize] = useState(10)
  const [refreshing, setRefreshing] = useState(false)

  useEffect(() => {
    if (user) {
      Promise.all([
        fetchWalletStats(),
        fetchConfig(),
        fetchTransactions(currentPage)
      ]).finally(() => setLoading(false))
    }
  }, [user, currentPage])

  const fetchWalletStats = async () => {
    try {
      const response = await fetch('/api/wallet/stats')
      if (!response.ok) throw new Error('Failed to fetch wallet stats')
      const data = await response.json()
      setStats(data.stats)
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      })
    }
  }

  const fetchConfig = async () => {
    try {
      const response = await fetch('/api/wallet/config')
      if (!response.ok) throw new Error('Failed to fetch config')
      const data = await response.json()
      setConfig(data.config)
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      })
    }
  }

  const fetchTransactions = async (page: number) => {
    try {
      const response = await fetch(`/api/wallet/transactions?page=${page}&limit=${pageSize}`)
      if (!response.ok) throw new Error('Failed to fetch transactions')
      const data = await response.json()
      setTransactions(data.transactions || [])
      setTotalPages(data.totalPages || 1)
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      })
    }
  }

  const handleRefresh = async () => {
    setRefreshing(true)
    await Promise.all([
      fetchWalletStats(),
      fetchTransactions(currentPage)
    ])
    setRefreshing(false)
    toast({
      title: "Refreshed",
      description: "Wallet data updated successfully",
    })
  }

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
  }

  const getTransactionIcon = (kind: string) => {
    switch (kind) {
      case 'task_reward':
        return <ArrowUpLeft className="h-4 w-4 text-green-600" />
      case 'referral_bonus':
        return <TrendingUp className="h-4 w-4 text-blue-600" />
      case 'payout':
        return <ArrowDownRight className="h-4 w-4 text-red-600" />
      case 'bonus':
        return <Coins className="h-4 w-4 text-yellow-600" />
      default:
        return <History className="h-4 w-4 text-gray-600" />
    }
  }

  const getTransactionBadge = (kind: string) => {
    const variants: Record<string, { label: string; className: string }> = {
      'task_reward': { label: 'Task Reward', className: 'bg-green-100 text-green-800' },
      'referral_bonus': { label: 'Referral Bonus', className: 'bg-blue-100 text-blue-800' },
      'payout': { label: 'Payout', className: 'bg-red-100 text-red-800' },
      'bonus': { label: 'Bonus', className: 'bg-yellow-100 text-yellow-800' },
      'adjustment': { label: 'Adjustment', className: 'bg-gray-100 text-gray-800' }
    }
    
    const variant = variants[kind] || { label: kind, className: 'bg-gray-100 text-gray-800' }
    return <Badge className={variant.className}>{variant.label}</Badge>
  }

  const downloadTransactionHistory = async () => {
    try {
      const response = await fetch('/api/wallet/transactions/export')
      if (!response.ok) throw new Error('Failed to export transactions')
      
      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `transaction-history-${new Date().toISOString().split('T')[0]}.csv`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
      
      toast({
        title: "Downloaded",
        description: "Transaction history downloaded successfully",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      })
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-600"></div>
      </div>
    )
  }

  if (!user || !stats || !config) {
    return null
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Wallet</h1>
            <p className="text-muted-foreground">Manage your earnings and payouts</p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              onClick={handleRefresh}
              disabled={refreshing}
            >
              {refreshing ? (
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-2" />
              )}
              Refresh
            </Button>
            <Button onClick={() => window.location.href = '/payout'}>
              <ArrowUpRight className="h-4 w-4 mr-2" />
              Request Payout
            </Button>
          </div>
        </div>

        {/* Wallet Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Points</CardTitle>
              <Coins className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total_points.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                {config.points_to_inr_rate} points = ₹1
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Available Balance</CardTitle>
              <IndianRupee className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{stats.balance_inr.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">
                Ready for withdrawal
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Earnings</CardTitle>
              <TrendingUp className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{stats.total_earnings_inr.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">
                All time earnings
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tasks Completed</CardTitle>
              <History className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total_tasks_completed}</div>
              <p className="text-xs text-muted-foreground">
                {stats.pending_payouts} pending payouts
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Conversion Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="h-5 w-5" />
              Conversion Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-2xl font-bold text-green-600">{config.points_to_inr_rate}</div>
                <div className="text-sm text-muted-foreground">Points = ₹1</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-2xl font-bold text-blue-600">₹{config.min_payout_threshold}</div>
                <div className="text-sm text-muted-foreground">Minimum Payout</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-2xl font-bold text-purple-600">₹{config.max_payout_amount}</div>
                <div className="text-sm text-muted-foreground">Maximum Payout</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Transaction History */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5" />
                Transaction History
              </CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={downloadTransactionHistory}
              >
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {transactions.length === 0 ? (
              <div className="text-center py-8">
                <History className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No transactions yet</h3>
                <p className="text-muted-foreground">Start completing tasks to see your transaction history here!</p>
              </div>
            ) : (
              <>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Type</TableHead>
                      <TableHead>Points</TableHead>
                      <TableHead>Amount (₹)</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getTransactionIcon(transaction.kind)}
                            <div>
                              <div className="font-medium">{getTransactionBadge(transaction.kind)}</div>
                              {transaction.meta?.task_title && (
                                <div className="text-sm text-muted-foreground">
                                  {transaction.meta.task_title}
                                </div>
                              )}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className={transaction.points > 0 ? 'text-green-600' : 'text-red-600'}>
                            {transaction.points > 0 ? '+' : ''}{transaction.points}
                          </span>
                        </TableCell>
                        <TableCell>
                          <span className={transaction.inr_value > 0 ? 'text-green-600' : 'text-red-600'}>
                            {transaction.inr_value > 0 ? '+' : ''}₹{transaction.inr_value.toFixed(2)}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {new Date(transaction.created_at).toLocaleDateString()}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={transaction.status === 'completed' ? 'default' : 'secondary'}>
                            {transaction.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="mt-4">
                    <Pagination>
                      <PaginationContent>
                        <PaginationItem>
                          <PaginationPrevious
                            onClick={() => handlePageChange(Math.max(1, currentPage - 1))}
                            className={currentPage === 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                          />
                        </PaginationItem>
                        {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                          <PaginationItem key={page}>
                            <PaginationLink
                              onClick={() => handlePageChange(page)}
                              isActive={currentPage === page}
                              className="cursor-pointer"
                            >
                              {page}
                            </PaginationLink>
                          </PaginationItem>
                        ))}
                        <PaginationItem>
                          <PaginationNext
                            onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))}
                            className={currentPage === totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                          />
                        </PaginationItem>
                      </PaginationContent>
                    </Pagination>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}