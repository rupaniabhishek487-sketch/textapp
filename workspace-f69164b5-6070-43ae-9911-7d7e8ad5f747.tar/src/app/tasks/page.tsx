"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { useToast } from '@/hooks/use-toast'
import { useAuth } from '@/components/AuthProvider'
import { Clock, Coins, Play, CheckCircle, AlertCircle, Loader2, FileText, Link, Mic } from 'lucide-react'
import { Task, TaskSubmission } from '@/types/supabase'

interface TaskCardProps {
  task: Task
  onClaimTask: (taskId: string) => Promise<void>
  onSubmitTask: (taskId: string, submissionText?: string, submissionUrl?: string) => Promise<void>
  claimedTasks: Set<string>
}

function TaskCard({ task, onClaimTask, onSubmitTask, claimedTasks }: TaskCardProps) {
  const { user } = useAuth()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submissionText, setSubmissionText] = useState('')
  const [submissionUrl, setSubmissionUrl] = useState('')
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const isClaimed = claimedTasks.has(task.id)
  const getTaskIcon = (type: string) => {
    switch (type) {
      case 'typing': return <FileText className="h-4 w-4" />
      case 'transcription': return <Mic className="h-4 w-4" />
      case 'survey': return <FileText className="h-4 w-4" />
      default: return <FileText className="h-4 w-4" />
    }
  }

  const getTaskTypeColor = (type: string) => {
    switch (type) {
      case 'typing': return 'bg-blue-100 text-blue-800'
      case 'transcription': return 'bg-green-100 text-green-800'
      case 'survey': return 'bg-purple-100 text-purple-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const handleClaimTask = async () => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please login to claim tasks",
        variant: "destructive"
      })
      return
    }

    try {
      await onClaimTask(task.id)
      toast({
        title: "Task Claimed!",
        description: "You have 30 minutes to complete this task",
      })
    } catch (error: any) {
      toast({
        title: "Failed to Claim Task",
        description: error.message,
        variant: "destructive"
      })
    }
  }

  const handleSubmitTask = async () => {
    if (task.task_type === 'typing' && !submissionText.trim()) {
      toast({
        title: "Missing Content",
        description: "Please enter the typed text",
        variant: "destructive"
      })
      return
    }

    if (task.task_type === 'transcription' && !submissionUrl.trim()) {
      toast({
        title: "Missing Audio File",
        description: "Please provide an audio file URL",
        variant: "destructive"
      })
      return
    }

    setIsSubmitting(true)
    try {
      await onSubmitTask(task.id, submissionText, submissionUrl)
      setIsDialogOpen(false)
      setSubmissionText('')
      setSubmissionUrl('')
    } catch (error: any) {
      toast({
        title: "Submission Failed",
        description: error.message,
        variant: "destructive"
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card className="w-full hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            {getTaskIcon(task.task_type)}
            <Badge className={getTaskTypeColor(task.task_type)}>
              {task.task_type.charAt(0).toUpperCase() + task.task_type.slice(1)}
            </Badge>
          </div>
          <div className="flex items-center gap-1 text-yellow-600">
            <Coins className="h-4 w-4" />
            <span className="font-semibold">{task.reward_points}</span>
          </div>
        </div>
        <CardTitle className="text-lg leading-tight">{task.title}</CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground line-clamp-2">
          {task.description}
        </p>
        
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span>{task.task_type === 'typing' ? '2-5 min' : task.task_type === 'transcription' ? '10-15 min' : '5-10 min'}</span>
          </div>
          <Badge variant="outline" className="text-xs">
            {task.task_type === 'typing' ? 'Easy' : task.task_type === 'transcription' ? 'Medium' : 'Easy'}
          </Badge>
        </div>

        <div className="flex gap-2">
          {!isClaimed ? (
            <Button 
              onClick={handleClaimTask}
              className="flex-1"
              disabled={!user}
            >
              <Play className="h-4 w-4 mr-2" />
              Claim Task
            </Button>
          ) : (
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="flex-1">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Submit Task
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>Submit Task: {task.title}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  {task.task_type === 'typing' && (
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Typed Text</label>
                      <Textarea
                        placeholder="Paste the text you typed here..."
                        value={submissionText}
                        onChange={(e) => setSubmissionText(e.target.value)}
                        rows={6}
                      />
                    </div>
                  )}
                  
                  {task.task_type === 'transcription' && (
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Audio File URL</label>
                      <Input
                        placeholder="Enter audio file URL..."
                        value={submissionUrl}
                        onChange={(e) => setSubmissionUrl(e.target.value)}
                      />
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      onClick={() => setIsDialogOpen(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleSubmitTask}
                      disabled={isSubmitting}
                      className="flex-1"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Submitting...
                        </>
                      ) : (
                        <>
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Submit
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

export default function TasksPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [tasks, setTasks] = useState<Task[]>([])
  const [claimedTasks, setClaimedTasks] = useState<Set<string>>(new Set())
  const [userPoints, setUserPoints] = useState(0)
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<'all' | 'typing' | 'transcription' | 'survey'>('all')

  useEffect(() => {
    if (user) {
      Promise.all([
        fetchTasks(),
        fetchClaimedTasks(),
        fetchUserPoints()
      ]).finally(() => setLoading(false))
    } else {
      fetchTasks().finally(() => setLoading(false))
    }
  }, [user])

  const fetchTasks = async () => {
    try {
      const response = await fetch('/api/tasks')
      if (!response.ok) throw new Error('Failed to fetch tasks')
      const data = await response.json()
      setTasks(data.tasks || [])
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      })
    }
  }

  const fetchClaimedTasks = async () => {
    if (!user) return
    
    try {
      const response = await fetch('/api/user/claimed-tasks')
      if (!response.ok) throw new Error('Failed to fetch claimed tasks')
      const data = await response.json()
      setClaimedTasks(new Set(data.claimedTasks?.map((t: TaskSubmission) => t.task_id) || []))
    } catch (error: any) {
      console.error('Error fetching claimed tasks:', error)
    }
  }

  const fetchUserPoints = async () => {
    if (!user) return
    
    try {
      const response = await fetch('/api/user/points')
      if (!response.ok) throw new Error('Failed to fetch user points')
      const data = await response.json()
      setUserPoints(data.points || 0)
    } catch (error: any) {
      console.error('Error fetching user points:', error)
    }
  }

  const handleClaimTask = async (taskId: string) => {
    const response = await fetch('/api/claim-task', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ taskId })
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to claim task')
    }

    const data = await response.json()
    setClaimedTasks(prev => new Set([...prev, taskId]))
  }

  const handleSuccess = () => {
    // Show success animation
    const successAnimation = document.createElement('div')
    successAnimation.className = 'fixed inset-0 z-50 flex items-center justify-center bg-black/50'
    successAnimation.innerHTML = `
      <div class="bg-white rounded-lg p-8 max-w-sm mx-4 text-center animate-bounce">
        <div class="text-6xl mb-4">🎉</div>
        <h2 class="text-2xl font-bold text-green-600 mb-2">Task Completed!</h2>
        <p class="text-gray-600">You earned points!</p>
      </div>
    `
    document.body.appendChild(successAnimation)
    
    setTimeout(() => {
      document.body.removeChild(successAnimation)
    }, 2000)
  }

  const handleSubmitTask = async (taskId: string, submissionText?: string, submissionUrl?: string) => {
    let similarityScore = 0
    
    // Client-side text similarity check for text tasks
    if (submissionText) {
      const task = tasks.find(t => t.id === taskId)
      if (task?.expected_text) {
        const expected = task.expected_text.trim().toLowerCase()
        const submitted = submissionText.trim().toLowerCase()
        
        // Simple similarity check
        if (expected === submitted) {
          similarityScore = 1.0
        } else {
          // Calculate character-level similarity
          const maxLength = Math.max(expected.length, submitted.length)
          const matches = expected.split('').filter((char, index) => submitted[index] === char).length
          similarityScore = matches / maxLength
        }
      }
    }

    const response = await fetch('/api/submit-task', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        taskId,
        submissionText,
        submissionUrl,
        similarityScore
      })
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to submit task')
    }

    const data = await response.json()
    
    // Update UI
    setClaimedTasks(prev => {
      const newSet = new Set(prev)
      newSet.delete(taskId)
      return newSet
    })
    
    setUserPoints(prev => prev + (data.pointsAwarded || 0))
    
    // Show success animation
    handleSuccess()
    
    toast({
      title: "Task Submitted Successfully!",
      description: `You earned ${data.pointsAwarded || 0} points!`,
    })
  }

  const filteredTasks = tasks.filter(task => 
    filter === 'all' || task.task_type === filter
  )

  if (loading) {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-center min-h-[400px]">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Task Hub</h1>
            <p className="text-muted-foreground">Complete tasks to earn rewards</p>
          </div>
          {user && (
            <div className="flex items-center gap-2 bg-yellow-50 px-4 py-2 rounded-lg border">
              <Coins className="h-5 w-5 text-yellow-600" />
              <span className="font-semibold text-yellow-800">{userPoints} Points</span>
            </div>
          )}
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap gap-2">
          {[
            { value: 'all', label: 'All Tasks' },
            { value: 'typing', label: 'Typing' },
            { value: 'transcription', label: 'Transcription' },
            { value: 'survey', label: 'Surveys' }
          ].map((tab) => (
            <Button
              key={tab.value}
              variant={filter === tab.value ? 'default' : 'outline'}
              onClick={() => setFilter(tab.value as any)}
              size="sm"
            >
              {tab.label}
            </Button>
          ))}
        </div>

        {/* Tasks Grid */}
        {filteredTasks.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📋</div>
            <h3 className="text-xl font-semibold mb-2">No tasks available</h3>
            <p className="text-muted-foreground">
              {filter === 'all' 
                ? "Check back later for new tasks" 
                : `No ${filter} tasks available right now`
              }
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTasks.map((task) => (
              <TaskCard
                key={task.id}
                task={task}
                onClaimTask={handleClaimTask}
                onSubmitTask={handleSubmitTask}
                claimedTasks={claimedTasks}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}