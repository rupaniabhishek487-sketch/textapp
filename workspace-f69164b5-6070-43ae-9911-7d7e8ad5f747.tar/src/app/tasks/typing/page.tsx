"use client"

import { useAuth } from "@/components/AuthProvider"
import { useRouter, useSearchParams } from "next/navigation"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { 
  FileText, 
  Clock, 
  Coins, 
  ArrowLeft, 
  ArrowRight,
  CheckCircle,
  AlertCircle,
  Loader2
} from "lucide-react"
import { supabase } from "@/lib/supabaseClient"

interface Task {
  id: string
  title: string
  description: string
  task_type: string
  reward_points: number
  payload_url?: string
  max_completions: number
  active: boolean
  created_at: string
}

export default function TypingTaskPage() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()
  const taskId = searchParams.get("id")

  const [task, setTask] = useState<Task | null>(null)
  const [loadingTask, setLoadingTask] = useState(true)
  const [taskText, setTaskText] = useState("")
  const [userInput, setUserInput] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submissionResult, setSubmissionResult] = useState<{
    success: boolean
    message: string
    points?: number
  } | null>(null)
  const [timeLeft, setTimeLeft] = useState(300) // 5 minutes in seconds
  const [isTimerActive, setIsTimerActive] = useState(false)

  useEffect(() => {
    if (!loading && !user) {
      router.push("/login")
    }
  }, [loading, user, router])

  useEffect(() => {
    if (taskId && user) {
      fetchTask()
    }
  }, [taskId, user])

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isTimerActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((time) => time - 1)
      }, 1000)
    } else if (timeLeft === 0) {
      handleSubmit() // Auto-submit when time runs out
    }
    return () => clearInterval(interval)
  }, [isTimerActive, timeLeft])

  const fetchTask = async () => {
    if (!taskId) return

    try {
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .eq('id', taskId)
        .eq('active', true)
        .single()

      if (error) {
        console.error("Task fetch error:", error)
        router.push("/tasks")
      } else {
        setTask(data)
        // Generate sample task text (in production, this would come from payload_url)
        setTaskText(generateSampleTaskText())
      }
    } catch (error) {
      console.error("Failed to fetch task:", error)
      router.push("/tasks")
    } finally {
      setLoadingTask(false)
    }
  }

  const generateSampleTaskText = () => {
    return "The quick brown fox jumps over the lazy dog. This pangram sentence contains every letter of the alphabet at least once. It is commonly used for testing typewriters, computer keyboards, and font samples. The sentence has been used since at least the late 19th century. Practice typing this text to improve your typing speed and accuracy. Remember to focus on proper finger placement and maintain a steady rhythm while typing."
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const calculateSimilarity = (text1: string, text2: string): number => {
    const normalize = (str: string) => str.toLowerCase().replace(/\s+/g, ' ').trim()
    const normalized1 = normalize(text1)
    const normalized2 = normalize(text2)
    
    const longer = normalized1.length > normalized2.length ? normalized1 : normalized2
    const shorter = normalized1.length > normalized2.length ? normalized2 : normalized1
    
    if (longer.length === 0) return 100.0
    
    const editDistance = levenshteinDistance(longer, shorter)
    return ((longer.length - editDistance) / longer.length) * 100
  }

  const levenshteinDistance = (str1: string, str2: string): number => {
    const matrix = []
    
    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i]
    }
    
    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j
    }
    
    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1]
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          )
        }
      }
    }
    
    return matrix[str2.length][str1.length]
  }

  const handleSubmit = async () => {
    if (!task || !user) return

    setIsSubmitting(true)
    setSubmissionResult(null)

    try {
      const similarity = calculateSimilarity(taskText, userInput)
      const passed = similarity >= 80 // 80% similarity threshold

      // Submit task
      const { data: submission, error: submissionError } = await supabase
        .from('task_submissions')
        .insert({
          task_id: task.id,
          user_id: user.id,
          submission_text: userInput,
          auto_score: similarity,
          status: passed ? 'approved' : 'rejected',
          reward_points: passed ? task.reward_points : 0
        })
        .select()
        .single()

      if (submissionError) {
        throw submissionError
      }

      // If passed, create transaction and update profile
      if (passed) {
        // Create transaction
        await supabase
          .from('transactions')
          .insert({
            user_id: user.id,
            kind: 'task_reward',
            points: task.reward_points,
            inr_value: task.reward_points * 0.01, // 1 point = ₹0.01
            meta: {
              task_id: task.id,
              task_title: task.title,
              similarity_score: similarity
            }
          })

        // Update profile
        await supabase
          .from('profiles')
          .update({
            points: supabase.rpc('increment', { x: task.reward_points }),
            balance_inr: supabase.rpc('increment', { x: task.reward_points * 0.01 }),
            total_tasks_completed: supabase.rpc('increment', { x: 1 }),
            total_earnings_inr: supabase.rpc('increment', { x: task.reward_points * 0.01 })
          })
          .eq('id', user.id)
      }

      setSubmissionResult({
        success: passed,
        message: passed 
          ? `Task completed successfully! You earned ${task.reward_points} points.`
          : `Task not approved. Similarity: ${similarity.toFixed(1)}%. Minimum required: 80%`,
        points: passed ? task.reward_points : 0
      })

    } catch (error) {
      console.error("Submission error:", error)
      setSubmissionResult({
        success: false,
        message: "Failed to submit task. Please try again."
      })
    } finally {
      setIsSubmitting(false)
      setIsTimerActive(false)
    }
  }

  const handleStartTask = () => {
    setIsTimerActive(true)
  }

  const handleContinue = () => {
    if (submissionResult?.success) {
      router.push("/tasks")
    } else {
      // Allow retry
      setSubmissionResult(null)
      setUserInput("")
      setTimeLeft(300)
    }
  }

  if (loading || loadingTask) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-600"></div>
      </div>
    )
  }

  if (!user || !task) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => router.push("/tasks")}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Tasks
              </Button>
              <h1 className="text-2xl font-bold text-green-600">Typing Task</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-yellow-600">
                <Coins className="h-4 w-4" />
                <span className="font-semibold">{task.reward_points} points</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">{task.title}</h2>
          <p className="text-gray-600">{task.description}</p>
        </div>

        {/* Timer */}
        <div className="mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4" />
                  <span className="font-medium">Time Remaining</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`font-mono text-lg ${timeLeft < 60 ? 'text-red-600' : 'text-gray-900'}`}>
                    {formatTime(timeLeft)}
                  </span>
                  {timeLeft < 60 && <AlertCircle className="h-4 w-4 text-red-600" />}
                </div>
              </div>
              <Progress value={(300 - timeLeft) / 3} className="mt-2" />
            </CardContent>
          </Card>
        </div>

        {!submissionResult ? (
          <div className="space-y-6">
            {/* Task Text */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="h-5 w-5" />
                  <span>Type the following text</span>
                </CardTitle>
                <CardDescription>
                  Type the text exactly as shown below. 80% accuracy required to pass.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="p-4 bg-gray-50 rounded-lg border font-mono text-sm leading-relaxed">
                  {taskText}
                </div>
              </CardContent>
            </Card>

            {/* User Input */}
            <Card>
              <CardHeader>
                <CardTitle>Your Typing</CardTitle>
                <CardDescription>
                  Type the text in the box below. Click "Start Task" to begin the timer.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="userInput">Your Text</Label>
                  <Textarea
                    id="userInput"
                    placeholder="Start typing here..."
                    value={userInput}
                    onChange={(e) => setUserInput(e.target.value)}
                    className="min-h-[200px] font-mono"
                    disabled={!isTimerActive && timeLeft === 300}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-sm text-muted-foreground">
                    Characters: {userInput.length} / {taskText.length}
                  </div>
                  <div className="space-x-2">
                    {!isTimerActive && timeLeft === 300 ? (
                      <Button onClick={handleStartTask}>
                        Start Task
                      </Button>
                    ) : (
                      <Button 
                        onClick={handleSubmit}
                        disabled={isSubmitting || userInput.length === 0}
                      >
                        {isSubmitting ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Submitting...
                          </>
                        ) : (
                          <>
                            Submit Task
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <Card>
            <CardContent className="p-8 text-center">
              <div className="mx-auto w-16 h-16 mb-4 flex items-center justify-center rounded-full bg-green-100">
                {submissionResult.success ? (
                  <CheckCircle className="h-8 w-8 text-green-600" />
                ) : (
                  <AlertCircle className="h-8 w-8 text-red-600" />
                )}
              </div>
              <h3 className="text-xl font-semibold mb-2">
                {submissionResult.success ? 'Task Completed!' : 'Task Not Approved'}
              </h3>
              <p className="text-gray-600 mb-6">{submissionResult.message}</p>
              {submissionResult.points && (
                <div className="mb-6">
                  <div className="inline-flex items-center space-x-2 bg-yellow-100 text-yellow-800 px-4 py-2 rounded-full">
                    <Coins className="h-4 w-4" />
                    <span className="font-semibold">+{submissionResult.points} points earned</span>
                  </div>
                </div>
              )}
              <Button onClick={handleContinue}>
                {submissionResult.success ? 'Continue to Tasks' : 'Try Again'}
              </Button>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  )
}