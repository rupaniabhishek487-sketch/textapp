"use client"

import { useAuth } from "@/components/AuthProvider"
import { useRouter, useSearchParams } from "next/navigation"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Mic, 
  Clock, 
  Coins, 
  ArrowLeft, 
  ArrowRight,
  CheckCircle,
  AlertCircle,
  Loader2,
  Upload,
  Play,
  Pause
} from "lucide-react"
import { supabase } from "@/lib/supabaseClient"

interface Task {
  id: string
  title: string
  description: string
  task_type: string
  reward_points: number
  payload_url?: string
  max_completions: number
  active: boolean
  created_at: string
}

export default function TranscriptionTaskPage() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()
  const taskId = searchParams.get("id")

  const [task, setTask] = useState<Task | null>(null)
  const [loadingTask, setLoadingTask] = useState(true)
  const [audioUrl, setAudioUrl] = useState("")
  const [transcription, setTranscription] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submissionResult, setSubmissionResult] = useState<{
    success: boolean
    message: string
    points?: number
  } | null>(null)
  const [timeLeft, setTimeLeft] = useState(600) // 10 minutes
  const [isTimerActive, setIsTimerActive] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)
  const [audioFile, setAudioFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)

  useEffect(() => {
    if (!loading && !user) {
      router.push("/login")
    }
  }, [loading, user, router])

  useEffect(() => {
    if (taskId && user) {
      fetchTask()
    }
  }, [taskId, user])

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isTimerActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((time) => time - 1)
      }, 1000)
    } else if (timeLeft === 0) {
      handleSubmit() // Auto-submit when time runs out
    }
    return () => clearInterval(interval)
  }, [isTimerActive, timeLeft])

  const fetchTask = async () => {
    if (!taskId) return

    try {
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .eq('id', taskId)
        .eq('active', true)
        .single()

      if (error) {
        console.error("Task fetch error:", error)
        router.push("/tasks")
      } else {
        setTask(data)
        // Set sample audio URL (in production, this would come from payload_url)
        setAudioUrl(data.payload_url || "https://example.com/sample-audio.mp3")
      }
    } catch (error) {
      console.error("Failed to fetch task:", error)
      router.push("/tasks")
    } finally {
      setLoadingTask(false)
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    // Validate file type
    if (!file.type.startsWith('audio/')) {
      alert('Please upload an audio file')
      return
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      alert('File size must be less than 10MB')
      return
    }

    setAudioFile(file)
    setUploading(true)

    try {
      // Upload to Supabase Storage
      const fileName = `${user!.id}/${Date.now()}_${file.name}`
      const { data, error } = await supabase.storage
        .from('audio-uploads')
        .upload(fileName, file)

      if (error) {
        throw error
      }

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('audio-uploads')
        .getPublicUrl(fileName)

      setAudioUrl(publicUrl)
    } catch (error) {
      console.error("Upload error:", error)
      alert("Failed to upload audio file")
    } finally {
      setUploading(false)
    }
  }

  const togglePlayback = () => {
    setIsPlaying(!isPlaying)
    // In a real implementation, you would control actual audio playback here
  }

  const handleSubmit = async () => {
    if (!task || !user) return

    if (!transcription.trim()) {
      alert("Please provide a transcription")
      return
    }

    setIsSubmitting(true)
    setSubmissionResult(null)

    try {
      // For demo purposes, we'll auto-approve transcription tasks
      // In production, you might want to implement quality checks
      const passed = transcription.trim().length > 50 // Basic validation

      // Submit task
      const { data: submission, error: submissionError } = await supabase
        .from('task_submissions')
        .insert({
          task_id: task.id,
          user_id: user.id,
          submission_text: transcription,
          submission_url: audioUrl,
          auto_score: passed ? 100 : 0,
          status: passed ? 'approved' : 'pending', // Transcription tasks might need manual review
          reward_points: passed ? task.reward_points : 0
        })
        .select()
        .single()

      if (submissionError) {
        throw submissionError
      }

      // If passed, create transaction and update profile
      if (passed) {
        // Create transaction
        await supabase
          .from('transactions')
          .insert({
            user_id: user.id,
            kind: 'task_reward',
            points: task.reward_points,
            inr_value: task.reward_points * 0.01, // 1 point = ₹0.01
            meta: {
              task_id: task.id,
              task_title: task.title,
              audio_url: audioUrl
            }
          })

        // Update profile
        await supabase
          .from('profiles')
          .update({
            points: supabase.rpc('increment', { x: task.reward_points }),
            balance_inr: supabase.rpc('increment', { x: task.reward_points * 0.01 }),
            total_tasks_completed: supabase.rpc('increment', { x: 1 }),
            total_earnings_inr: supabase.rpc('increment', { x: task.reward_points * 0.01 })
          })
          .eq('id', user.id)
      }

      setSubmissionResult({
        success: passed,
        message: passed 
          ? `Transcription submitted successfully! You earned ${task.reward_points} points.`
          : `Transcription submitted for review. You will be notified once approved.`,
        points: passed ? task.reward_points : 0
      })

    } catch (error) {
      console.error("Submission error:", error)
      setSubmissionResult({
        success: false,
        message: "Failed to submit transcription. Please try again."
      })
    } finally {
      setIsSubmitting(false)
      setIsTimerActive(false)
    }
  }

  const handleStartTask = () => {
    setIsTimerActive(true)
  }

  const handleContinue = () => {
    if (submissionResult?.success) {
      router.push("/tasks")
    } else {
      // Allow retry
      setSubmissionResult(null)
      setTranscription("")
      setTimeLeft(600)
    }
  }

  if (loading || loadingTask) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-600"></div>
      </div>
    )
  }

  if (!user || !task) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => router.push("/tasks")}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Tasks
              </Button>
              <h1 className="text-2xl font-bold text-green-600">Transcription Task</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-yellow-600">
                <Coins className="h-4 w-4" />
                <span className="font-semibold">{task.reward_points} points</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">{task.title}</h2>
          <p className="text-gray-600">{task.description}</p>
        </div>

        {/* Timer */}
        <div className="mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4" />
                  <span className="font-medium">Time Remaining</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`font-mono text-lg ${timeLeft < 60 ? 'text-red-600' : 'text-gray-900'}`}>
                    {formatTime(timeLeft)}
                  </span>
                  {timeLeft < 60 && <AlertCircle className="h-4 w-4 text-red-600" />}
                </div>
              </div>
              <Progress value={(600 - timeLeft) / 6} className="mt-2" />
            </CardContent>
          </Card>
        </div>

        {!submissionResult ? (
          <div className="space-y-6">
            {/* Audio Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Mic className="h-5 w-5" />
                  <span>Audio Source</span>
                </CardTitle>
                <CardDescription>
                  Upload your own audio file or use the provided audio URL
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="upload" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="upload">Upload Audio</TabsTrigger>
                    <TabsTrigger value="url">Use URL</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="upload" className="space-y-4">
                    <div>
                      <Label htmlFor="audioFile">Upload Audio File</Label>
                      <Input
                        id="audioFile"
                        type="file"
                        accept="audio/*"
                        onChange={handleFileUpload}
                        disabled={uploading}
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Supported formats: MP3, WAV, M4A (Max 10MB)
                      </p>
                    </div>
                    {audioFile && (
                      <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                        <p className="text-sm text-green-800">
                          ✓ {audioFile.name} uploaded successfully
                        </p>
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="url" className="space-y-4">
                    <div>
                      <Label htmlFor="audioUrl">Audio URL</Label>
                      <Input
                        id="audioUrl"
                        type="url"
                        placeholder="https://example.com/audio.mp3"
                        value={audioUrl}
                        onChange={(e) => setAudioUrl(e.target.value)}
                      />
                    </div>
                    {audioUrl && (
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          onClick={togglePlayback}
                          className="flex items-center space-x-2"
                        >
                          {isPlaying ? (
                            <>
                              <Pause className="h-4 w-4" />
                              <span>Pause</span>
                            </>
                          ) : (
                            <>
                              <Play className="h-4 w-4" />
                              <span>Play Audio</span>
                            </>
                          )}
                        </Button>
                        <span className="text-sm text-muted-foreground">
                          {isPlaying ? "Playing..." : "Click to play"}
                        </span>
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {/* Transcription Input */}
            <Card>
              <CardHeader>
                <CardTitle>Transcription</CardTitle>
                <CardDescription>
                  Type exactly what you hear in the audio. Include punctuation and formatting as accurately as possible.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="transcription">Your Transcription</Label>
                  <Textarea
                    id="transcription"
                    placeholder="Type the transcription here..."
                    value={transcription}
                    onChange={(e) => setTranscription(e.target.value)}
                    className="min-h-[250px]"
                    disabled={!isTimerActive && timeLeft === 600}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-sm text-muted-foreground">
                    Words: {transcription.split(/\s+/).filter(w => w.length > 0).length}
                  </div>
                  <div className="space-x-2">
                    {!isTimerActive && timeLeft === 600 ? (
                      <Button onClick={handleStartTask}>
                        Start Task
                      </Button>
                    ) : (
                      <Button 
                        onClick={handleSubmit}
                        disabled={isSubmitting || transcription.trim().length === 0}
                      >
                        {isSubmitting ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Submitting...
                          </>
                        ) : (
                          <>
                            Submit Transcription
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <Card>
            <CardContent className="p-8 text-center">
              <div className="mx-auto w-16 h-16 mb-4 flex items-center justify-center rounded-full bg-green-100">
                {submissionResult.success ? (
                  <CheckCircle className="h-8 w-8 text-green-600" />
                ) : (
                  <AlertCircle className="h-8 w-8 text-yellow-600" />
                )}
              </div>
              <h3 className="text-xl font-semibold mb-2">
                {submissionResult.success ? 'Transcription Submitted!' : 'Under Review'}
              </h3>
              <p className="text-gray-600 mb-6">{submissionResult.message}</p>
              {submissionResult.points && (
                <div className="mb-6">
                  <div className="inline-flex items-center space-x-2 bg-yellow-100 text-yellow-800 px-4 py-2 rounded-full">
                    <Coins className="h-4 w-4" />
                    <span className="font-semibold">+{submissionResult.points} points earned</span>
                  </div>
                </div>
              )}
              <Button onClick={handleContinue}>
                {submissionResult.success ? 'Continue to Tasks' : 'Submit Another'}
              </Button>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  )
}