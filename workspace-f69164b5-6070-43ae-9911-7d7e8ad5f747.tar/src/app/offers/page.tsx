'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { 
  ExternalLink, 
  Gift, 
  Star, 
  Clock, 
  Play, 
  Eye, 
  CheckCircle,
  AlertCircle,
  TrendingUp
} from 'lucide-react'
import Link from 'next/link'

interface Offer {
  id: string
  title: string
  description: string
  reward_points: number
  reward_type: 'instant' | 'verification'
  category: 'survey' | 'offerwall' | 'video' | 'app_install'
  partner_name: string
  partner_logo?: string
  url: string
  requirements?: string
  time_to_complete?: string
  active: boolean
  featured?: boolean
}

export default function OffersPage() {
  const { toast } = useToast()
  const [offers, setOffers] = useState<Offer[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedCategory, setSelectedCategory] = useState<string>('all')

  useEffect(() => {
    fetchOffers()
  }, [])

  const fetchOffers = async () => {
    try {
      // Mock data - in real implementation, this would come from external offerwall APIs
      const mockOffers: Offer[] = [
        {
          id: '1',
          title: 'Complete Daily Survey',
          description: 'Share your opinion on products you use',
          reward_points: 50,
          reward_type: 'verification',
          category: 'survey',
          partner_name: 'SurveyPro',
          url: '#',
          requirements: 'Must complete entire survey honestly',
          time_to_complete: '5 minutes',
          active: true,
          featured: true
        },
        {
          id: '2',
          title: 'Download New Game',
          description: 'Install and play this exciting new game',
          reward_points: 100,
          reward_type: 'instant',
          category: 'app_install',
          partner_name: 'GameStudio',
          url: '#',
          requirements: 'Must reach level 5 in game',
          time_to_complete: '10 minutes',
          active: true,
          featured: false
        },
        {
          id: '3',
          title: 'Watch Product Demo',
          description: 'Watch 30-second product demonstration and provide feedback',
          reward_points: 25,
          reward_type: 'verification',
          category: 'video',
          partner_name: 'BrandX',
          url: '#',
          requirements: 'Must watch entire video',
          time_to_complete: '30 seconds',
          active: true,
          featured: false
        },
        {
          id: '4',
          title: 'Sign Up for Newsletter',
          description: 'Subscribe to our newsletter and get instant bonus',
          reward_points: 20,
          reward_type: 'instant',
          category: 'offerwall',
          partner_name: 'Earnify',
          url: '#',
          requirements: 'Valid email address required',
          time_to_complete: '1 minute',
          active: true,
          featured: false
        },
        {
          id: '5',
          title: 'Complete Profile Setup',
          description: 'Fill out your complete profile to earn bonus',
          reward_points: 30,
          reward_type: 'verification',
          category: 'offerwall',
          partner_name: 'Earnify',
          url: '#',
          requirements: 'Add profile picture, phone number, and preferences',
          time_to_complete: '3 minutes',
          active: true,
          featured: false
        },
        {
          id: '6',
          title: 'Refer a Friend',
          description: 'Invite your friends to join Earnify and earn rewards',
          reward_points: 75,
          reward_type: 'instant',
          category: 'offerwall',
          partner_name: 'Earnify',
          url: '#',
          requirements: 'Friend must complete at least one task',
          time_to_complete: 'Depends on friend activity',
          active: true,
          featured: true
        },
        {
          id: '7',
          title: 'Daily Check-in Bonus',
          description: 'Check in to the app daily to earn bonus points',
          reward_points: 15,
          reward_type: 'instant',
          category: 'offerwall',
          partner_name: 'Earnify',
          url: '#',
          requirements: 'Must check in at least once per day',
          time_to_complete: '30 seconds',
          active: true,
          featured: false
        }
      ]

      setOffers(mockOffers)
      setLoading(false)
    } catch (error) {
      console.error('Failed to fetch offers:', error)
      toast({
        title: "Error",
        description: "Failed to load offers",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const filteredOffers = offers.filter(offer => {
    if (selectedCategory === 'all') return true
    return offer.category === selectedCategory
  })

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      survey: 'bg-green-100 text-green-800',
      offerwall: 'bg-blue-100 text-blue-800',
      video: 'bg-purple-100 text-purple-800',
      app_install: 'bg-orange-100 text-orange-800',
      all: 'bg-gray-100 text-gray-800'
    }
    return colors[category] || 'bg-gray-100 text-gray-800'
  }

  const getRewardTypeIcon = (type: string) => {
    const icons: { [key: string]: React.ReactNode } = {
      instant: <CheckCircle className="h-4 w-4" />,
      verification: <Star className="h-4 w-4" />
    }
    return icons[type] || <CheckCircle className="h-4 w-4" />
  }

  const handleOfferClick = async (offer: Offer) => {
    try {
      // In real implementation, this would open external offerwall
      if (offer.url === '#') {
        toast({
          title: "Coming Soon",
          description: "This offer will be available soon!",
        })
        return
      }

      // Simulate offer completion
      const response = await fetch('/api/offers/callback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          offer_id: offer.id,
          action: 'click',
          user_agent: navigator.userAgent
        })
      })

      if (response.ok) {
        const data = await response.json()
        toast({
          title: "Offer Started",
          description: data.message || "Offer tracking initiated",
        })
      } else {
        toast({
          title: "Offer Failed",
          description: "Failed to start offer",
          variant: "destructive"
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process offer",
        variant: "destructive"
      })
    }
  }

  const categories = [
    { id: 'all', name: 'All Offers', icon: 'Grid3X3' },
    { id: 'survey', name: 'Surveys', icon: 'FileText' },
    { id: 'offerwall', name: 'Offerwall', icon: 'Gift' },
    { id: 'video', name: 'Watch Videos', icon: 'Play' },
    { id: 'app_install', name: 'Apps', icon: 'Smartphone' }
  ]

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2">Offers & Surveys</h1>
          <p className="text-muted-foreground">
            Complete offers and surveys to earn extra points
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Available Offers</CardTitle>
              <TrendingUp className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{offers.length}</div>
              <p className="text-xs text-muted-foreground">
                Active offers available now
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Bonus</CardTitle>
              <Gift className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">75</div>
              <p className="text-xs text-muted-foreground">
                Potential bonus points from offers
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completed Today</CardTitle>
              <CheckCircle className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12</div>
              <p className="text-xs text-muted-foreground">
                Offers completed today
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Category Filter */}
        <Card>
          <CardHeader>
            <CardTitle>Categories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category.id)}
                  className="flex items-center gap-2"
                >
                  <category.icon className="h-4 w-4" />
                  <span>{category.name}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Offers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredOffers.map((offer) => (
            <Card key={offer.id} className="hover:shadow-lg transition-shadow cursor-pointer">
              {offer.featured && (
                <div className="absolute top-2 right-2 z-10">
                  <Badge className="bg-yellow-100 text-yellow-800">
                    <Star className="h-3 w-3 mr-1" />
                    Featured
                  </Badge>
                </div>
              )}
              
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getCategoryColor(offer.category)}`}>
                        <span className="text-white font-bold text-sm">
                          {offer.category.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">{offer.title}</h3>
                        <p className="text-sm text-muted-foreground">{offer.description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-green-600">+{offer.reward_points}</div>
                      <p className="text-xs text-muted-foreground">points</p>
                    </div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  <span>{offer.time_to_complete}</span>
                  <span className="mx-2">•</span>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(offer.category)}`}>
                    {offer.reward_type === 'instant' ? 'Instant' : 'Verification'}
                  </div>
                  {getRewardTypeIcon(offer.reward_type)}
                </div>
                
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <ExternalLink className="h-4 w-4" />
                  <span>{offer.partner_name}</span>
                  {offer.requirements && (
                    <span className="text-blue-600">• {offer.requirements}</span>
                  )}
                </div>
                
                <div className="flex items-center justify-between">
                  <Button 
                    onClick={() => handleOfferClick(offer)}
                    className="w-full"
                    disabled={offer.url === '#'}
                  >
                    {offer.url === '#' ? (
                      <>
                        <Eye className="h-4 w-4 mr-2" />
                        Coming Soon
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Start Offer
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Info Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-yellow-600" />
              How It Works
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <h4 className="font-semibold">Earn Points Instantly</h4>
              <p className="text-sm text-muted-foreground">
                Complete surveys, download apps, or watch videos to earn points immediately.
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold">Verification Required</h4>
              <p className="text-sm text-muted-foreground">
                Some offers require verification to ensure completion and prevent fraud.
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold">Tracked Completion</h4>
              <p className="text-sm text-muted-foreground">
                All offer completions are tracked and points are credited to your account.
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold">Safe & Secure</h4>
              <p className="text-sm text-muted-foreground">
                All offers are from trusted partners and are regularly monitored for quality.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}