'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useToast } from '@/hooks/use-toast'
import { CheckCircle, AlertCircle, Loader2, Download, Copy, ExternalLink } from 'lucide-react'

export default function SetupPage() {
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [results, setResults] = useState<any[]>([])

  const prepareSchema = async () => {
    setLoading(true)
    setResults([])
    
    try {
      const response = await fetch('/api/setup/anti-fraud', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      })

      const data = await response.json()
      
      if (response.ok) {
        setResults(data.results || [])
        toast({
          title: "Schema Prepared",
          description: "Anti-fraud schema is ready for manual application",
        })
      } else {
        toast({
          title: "Preparation Failed",
          description: data.error || "Failed to prepare anti-fraud schema",
          variant: "destructive"
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to connect to server",
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const downloadSchema = async () => {
    try {
      const response = await fetch('/api/setup/anti-fraud')
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = 'anti-fraud-schema.sql'
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
        
        toast({
          title: "Schema Downloaded",
          description: "anti-fraud-schema.sql has been downloaded",
        })
      }
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Failed to download schema file",
        variant: "destructive"
      })
    }
  }

  const copyToClipboard = async () => {
    try {
      const response = await fetch('/api/setup/anti-fraud')
      if (response.ok) {
        const text = await response.text()
        await navigator.clipboard.writeText(text)
        
        toast({
          title: "Copied to Clipboard",
          description: "Schema SQL has been copied to clipboard",
        })
      }
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy schema to clipboard",
        variant: "destructive"
      })
    }
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2">Anti-Fraud System Setup</h1>
          <p className="text-muted-foreground">
            Set up the anti-fraud system for Earnify
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>📋 What This Creates</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <h4 className="font-semibold text-green-600">📊 Database Tables:</h4>
                <ul className="text-sm text-muted-foreground list-disc list-inside space-y-1 ml-4">
                  <li><code>device_fingerprints</code> - Tracks devices and IPs</li>
                  <li><code>rate_limits</code> - Submission rate limiting</li>
                  <li><code>fraud_alerts</code> - Suspicious activity alerts</li>
                  <li><code>user_suspensions</code> - User suspension records</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold text-blue-600">🔧 Database Functions:</h4>
                <ul className="text-sm text-muted-foreground list-disc list-inside space-y-1 ml-4">
                  <li><code>record_device_fingerprint()</code> - Device tracking</li>
                  <li><code>check_rate_limit()</code> - Rate limiting</li>
                  <li><code>is_user_suspended()</code> - Suspension checks</li>
                  <li><code>suspend_user()</code> - User suspension</li>
                  <li><code>is_payout_eligible()</code> - 48-hour check</li>
                  <li><code>get_suspicious_users()</code> - Admin data</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold text-purple-600">🛡️ Security Features:</h4>
                <ul className="text-sm text-muted-foreground list-disc list-inside space-y-1 ml-4">
                  <li>Device fingerprinting & IP tracking</li>
                  <li>Multi-account detection</li>
                  <li>Rate limiting (30s/45s/50 daily)</li>
                  <li>48-hour payout hold for new accounts</li>
                  <li>User suspension system</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>🚀 Apply Schema</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <h4 className="font-semibold text-yellow-800 mb-2">⚠️ Manual Application Required</h4>
                <p className="text-sm text-yellow-700">
                  For security reasons, the database schema must be applied manually in your Supabase dashboard.
                </p>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold">📝 Step-by-Step Instructions:</h4>
                <ol className="text-sm text-muted-foreground list-decimal list-inside space-y-2 ml-4">
                  <li>Open your <strong>Supabase Dashboard</strong></li>
                  <li>Navigate to <strong>SQL Editor</strong></li>
                  <li>Download or copy the schema below</li>
                  <li>Paste the entire SQL in the editor</li>
                  <li>Click <strong>"Run"</strong> to execute</li>
                  <li>Verify all tables and functions are created</li>
                </ol>
              </div>

              <div className="flex flex-col gap-3">
                <Button 
                  onClick={prepareSchema} 
                  disabled={loading}
                  className="w-full"
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Preparing Schema...
                    </>
                  ) : (
                    'Prepare Schema'
                  )}
                </Button>

                <div className="grid grid-cols-2 gap-3">
                  <Button 
                    variant="outline" 
                    onClick={downloadSchema}
                    className="w-full"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download SQL
                  </Button>

                  <Button 
                    variant="outline" 
                    onClick={copyToClipboard}
                    className="w-full"
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Copy to Clipboard
                  </Button>
                </div>

                <Button 
                  variant="secondary" 
                  onClick={() => window.open('https://supabase.com/dashboard', '_blank')}
                  className="w-full"
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Open Supabase Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {results.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>📋 Schema Preparation Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {results.map((result, index) => (
                  <div key={index} className="flex items-center gap-2 text-sm p-2 bg-muted rounded">
                    {result.status === 'simulated' ? (
                      <CheckCircle className="h-4 w-4 text-blue-500" />
                    ) : (
                      <AlertCircle className="h-4 w-4 text-red-500" />
                    )}
                    <code className="text-xs bg-background px-2 py-1 rounded flex-1">
                      {result.statement}
                    </code>
                    <span className="text-muted-foreground text-xs">
                      {result.status}
                    </span>
                  </div>
                ))}
              </div>
              <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">✅ Next Steps:</h4>
                <p className="text-sm text-green-700">
                  The schema has been prepared. Now follow the manual application steps above to complete the setup.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>🔍 Verification</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              After applying the schema, verify the setup by checking:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <h4 className="font-semibold">In Supabase Dashboard:</h4>
                <ul className="text-sm text-muted-foreground list-disc list-inside space-y-1 ml-4">
                  <li>Table Editor shows 4 new tables</li>
                  <li>Database Functions shows 11 new functions</li>
                  <li>No error messages in execution</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">In Earnify App:</h4>
                <ul className="text-sm text-muted-foreground list-disc list-inside space-y-1 ml-4">
                  <li>Admin dashboard shows "Fraud Center" tab</li>
                  <li>Device fingerprinting works on login</li>
                  <li>Rate limiting enforced on submissions</li>
                  <li>48-hour hold applied to new accounts</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}