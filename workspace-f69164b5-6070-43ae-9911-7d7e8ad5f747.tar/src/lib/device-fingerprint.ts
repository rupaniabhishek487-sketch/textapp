import crypto from 'crypto'

export interface FingerprintData {
  userAgent: string
  language: string
  platform: string
  screen: string
  timezone: string
  canvas?: string
  webgl?: string
}

export class DeviceFingerprint {
  private static getCanvasFingerprint(): string {
    if (typeof window === 'undefined') return ''
    
    try {
      const canvas = document.createElement('canvas')
      const ctx = canvas.getContext('2d')
      if (!ctx) return ''
      
      // Draw a simple pattern
      ctx.textBaseline = 'top'
      ctx.font = '14px Arial'
      ctx.fillStyle = '#f60'
      ctx.fillRect(125, 1, 62, 20)
      ctx.fillStyle = '#069'
      ctx.fillText('Device fingerprint 🚀', 2, 15)
      ctx.fillStyle = 'rgba(102, 204, 0, 0.7)'
      ctx.fillText('Device fingerprint 🚀', 4, 17)
      
      return canvas.toDataURL().slice(-50) // Get last 50 chars
    } catch {
      return ''
    }
  }

  private static getWebGLFingerprint(): string {
    if (typeof window === 'undefined') return ''
    
    try {
      const canvas = document.createElement('canvas')
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl')
      if (!gl) return ''
      
      const debugInfo = gl.getExtension('WEBGL_debug_renderer_info')
      if (!debugInfo) return ''
      
      const vendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL)
      const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL)
      
      return `${vendor}|${renderer}`.slice(0, 100)
    } catch {
      return ''
    }
  }

  static generate(): string {
    if (typeof window === 'undefined') return 'server-fingerprint'
    
    const data: FingerprintData = {
      userAgent: navigator.userAgent,
      language: navigator.language,
      platform: navigator.platform,
      screen: `${screen.width}x${screen.height}x${screen.colorDepth}`,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      canvas: this.getCanvasFingerprint(),
      webgl: this.getWebGLFingerprint()
    }
    
    const fingerprintString = Object.values(data)
      .filter(Boolean)
      .join('|')
    
    return crypto.createHash('sha256')
      .update(fingerprintString)
      .digest('hex')
      .slice(0, 32) // First 32 chars for storage efficiency
  }

  static getClientIP(req?: any): string {
    // Try to get real IP from various headers
    const forwarded = req?.headers?.['x-forwarded-for']
    const realIP = req?.headers?.['x-real-ip']
    const cfConnectingIP = req?.headers?.['cf-connecting-ip']
    
    if (forwarded) {
      return forwarded.split(',')[0].trim()
    }
    
    if (realIP) {
      return realIP
    }
    
    if (cfConnectingIP) {
      return cfConnectingIP
    }
    
    return req?.socket?.remoteAddress || '127.0.0.1'
  }
}

// Client-side function to get fingerprint data
export function getFingerprintData(): FingerprintData {
  return {
    userAgent: navigator.userAgent,
    language: navigator.language,
    platform: navigator.platform,
    screen: `${screen.width}x${screen.height}x${screen.colorDepth}`,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    canvas: DeviceFingerprint.getCanvasFingerprint(),
    webgl: DeviceFingerprint.getWebGLFingerprint()
  }
}