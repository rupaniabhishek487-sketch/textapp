import { createClient } from '@/utils/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

export interface RateLimitConfig {
  actionType: string
  timeWindowSeconds: number
  maxAttempts: number
  errorMessage?: string
}

export class RateLimiter {
  static async checkRateLimit(
    userId: string,
    config: RateLimitConfig
  ): Promise<{ allowed: boolean; error?: string }> {
    const supabase = createClient()
    
    try {
      // Check rate limit using database function
      const { data: allowed, error } = await supabase.rpc('check_rate_limit', {
        p_user_id: userId,
        p_action_type: config.actionType,
        p_time_window_seconds: config.timeWindowSeconds,
        p_max_attempts: config.max_attempts
      })

      if (error) {
        console.error('Rate limit check error:', error)
        return { allowed: false, error: 'Rate limit check failed' }
      }

      if (!allowed) {
        return { 
          allowed: false, 
          error: config.errorMessage || `Rate limit exceeded for ${config.actionType}` 
        }
      }

      return { allowed: true }
    } catch (error) {
      console.error('Rate limit error:', error)
      return { allowed: false, error: 'Rate limit check failed' }
    }
  }

  static async recordAttempt(
    userId: string,
    actionType: string,
    metadata: Record<string, any> = {}
  ): Promise<void> {
    const supabase = createClient()
    
    try {
      await supabase.rpc('record_rate_limit_attempt', {
        p_user_id: userId,
        p_action_type: actionType,
        p_metadata: metadata
      })
    } catch (error) {
      console.error('Failed to record rate limit attempt:', error)
    }
  }

  static async checkDailyLimit(userId: string, maxDaily: number = 50): Promise<{ allowed: boolean; error?: string }> {
    const supabase = createClient()
    
    try {
      const { data: allowed, error } = await supabase.rpc('check_daily_submission_limit', {
        p_user_id: userId,
        p_max_daily: maxDaily
      })

      if (error) {
        console.error('Daily limit check error:', error)
        return { allowed: false, error: 'Daily limit check failed' }
      }

      if (!allowed) {
        return { 
          allowed: false, 
          error: `Daily submission limit of ${maxDaily} exceeded` 
        }
      }

      return { allowed: true }
    } catch (error) {
      console.error('Daily limit error:', error)
      return { allowed: false, error: 'Daily limit check failed' }
    }
  }
}

// Rate limit configurations
export const RATE_LIMITS = {
  TEXT_SUBMISSION: {
    actionType: 'text_submission',
    timeWindowSeconds: 30,
    maxAttempts: 1,
    errorMessage: 'Please wait 30 seconds before submitting another text task'
  },
  AUDIO_SUBMISSION: {
    actionType: 'audio_submission',
    timeWindowSeconds: 45,
    maxAttempts: 1,
    errorMessage: 'Please wait 45 seconds before submitting another audio task'
  },
  DAILY_SUBMISSIONS: {
    maxDaily: 50,
    errorMessage: 'You have reached the daily submission limit of 50 tasks'
  }
}

// Middleware function to check rate limits
export async function withRateLimit(
  request: NextRequest,
  userId: string,
  configs: RateLimitConfig[]
): Promise<{ allowed: boolean; error?: string }> {
  for (const config of configs) {
    const result = await RateLimiter.checkRateLimit(userId, config)
    if (!result.allowed) {
      return result
    }
  }

  // Also check daily limit for submissions
  if (configs.some(c => c.actionType.includes('submission'))) {
    const dailyResult = await RateLimiter.checkDailyLimit(userId)
    if (!dailyResult.allowed) {
      return dailyResult
    }
  }

  return { allowed: true }
}