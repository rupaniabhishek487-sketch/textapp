import { createClient } from '@supabase/supabase-js'

// Browser client - for client-side operations
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Supabase URL and Anon Key are required. Please check your .env.local file.')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Server client - for server-side operations (API routes, server components)
export const createSupabaseServerClient = () => {
  const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!supabaseServiceRoleKey) {
    throw new Error('Supabase Service Role Key is required for server operations.')
  }
  return createClient(supabaseUrl, supabaseServiceRoleKey)
}