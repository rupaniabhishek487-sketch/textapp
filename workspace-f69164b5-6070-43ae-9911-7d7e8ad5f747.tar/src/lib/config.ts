// Client-side configuration for environment variables
export const config = {
  supabaseUrl: process.env.NEXT_PUBLIC_SUPABASE_URL || '',
  supabaseAnonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '',
}

// Debug environment variables (remove in production)
if (typeof window !== 'undefined') {
  console.log('Environment variables loaded:', {
    supabaseUrl: !!config.supabaseUrl,
    supabaseAnonKey: !!config.supabaseAnonKey,
  })
}