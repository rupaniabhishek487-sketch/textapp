import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.38.4'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Only allow POST requests
    if (req.method !== 'POST') {
      return new Response(
        JSON.stringify({ error: 'Method not allowed' }),
        { status: 405, headers: corsHeaders }
      )
    }

    // Get authorization header
    const authHeader = req.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ error: 'Authorization required' }),
        { status: 401, headers: corsHeaders }
      )
    }

    // Create Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    // Verify JWT token
    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    )

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Invalid authentication' }),
        { status: 401, headers: corsHeaders }
      )
    }

    // Parse request body
    const body = await req.json()
    const { upiId, amount } = body

    // Validate input
    if (!upiId || !amount) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: upiId, amount' }),
        { status: 400, headers: corsHeaders }
      )
    }

    // Get configuration
    const pointsToInrRate = parseInt(Deno.env.get('POINTS_TO_INR_RATE') || '100')
    const minPayoutThreshold = parseFloat(Deno.env.get('MIN_PAYOUT_THRESHOLD') || '10')
    const maxPayoutAmount = parseFloat(Deno.env.get('MAX_PAYOUT_AMOUNT') || '10000')

    // Validate amount
    if (amount < minPayoutThreshold) {
      return new Response(
        JSON.stringify({ error: `Minimum payout amount is ₹${minPayoutThreshold}` }),
        { status: 400, headers: corsHeaders }
      )
    }

    if (amount > maxPayoutAmount) {
      return new Response(
        JSON.stringify({ error: `Maximum payout amount is ₹${maxPayoutAmount}` }),
        { status: 400, headers: corsHeaders }
      )
    }

    // Validate UPI ID format
    const upiRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+$/
    if (!upiRegex.test(upiId)) {
      return new Response(
        JSON.stringify({ error: 'Invalid UPI ID format' }),
        { status: 400, headers: corsHeaders }
      )
    }

    // Get user's current balance
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('total_points, balance_inr')
      .eq('id', user.id)
      .single()

    if (profileError || !profile) {
      return new Response(
        JSON.stringify({ error: 'Failed to fetch user profile' }),
        { status: 500, headers: corsHeaders }
      )
    }

    // Check if user has sufficient balance
    if (amount > profile.balance_inr) {
      return new Response(
        JSON.stringify({ error: 'Insufficient balance' }),
        { status: 400, headers: corsHeaders }
      )
    }

    // Calculate points to be used
    const pointsToUse = Math.round(amount * pointsToInrRate)

    // Check if user has sufficient points
    if (pointsToUse > profile.total_points) {
      return new Response(
        JSON.stringify({ error: 'Insufficient points' }),
        { status: 400, headers: corsHeaders }
      )
    }

    // Check for existing pending payout requests
    const { data: existingRequests, error: existingError } = await supabase
      .from('payout_requests')
      .select('id')
      .eq('user_id', user.id)
      .in('status', ['pending', 'processing'])

    if (existingError) {
      return new Response(
        JSON.stringify({ error: 'Failed to check existing requests' }),
        { status: 500, headers: corsHeaders }
      )
    }

    if (existingRequests && existingRequests.length > 0) {
      return new Response(
        JSON.stringify({ error: 'You already have a pending payout request' }),
        { status: 400, headers: corsHeaders }
      )
    }

    // Create payout request (points are NOT deducted yet)
    const { data: payoutRequest, error: payoutError } = await supabase
      .from('payout_requests')
      .insert({
        user_id: user.id,
        amount_points: pointsToUse,
        amount_inr: amount,
        upi_id: upiId.trim(),
        status: 'pending',
        notes: `Auto-generated request for ₹${amount}`,
        meta: {
          requested_via: 'edge_function',
          user_agent: req.headers.get('user-agent'),
          ip_address: req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip')
        }
      })
      .select()
      .single()

    if (payoutError) {
      return new Response(
        JSON.stringify({ error: 'Failed to create payout request' }),
        { status: 500, headers: corsHeaders }
      )
    }

    // Return success response
    return new Response(
      JSON.stringify({
        success: true,
        request: {
          id: payoutRequest.id,
          amount_inr: payoutRequest.amount_inr,
          points_used: payoutRequest.amount_points,
          status: payoutRequest.status,
          upi_id: payoutRequest.upi_id,
          message: 'Payout request created successfully. Points will be deducted upon admin approval.'
        }
      }),
      { 
        status: 200, 
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    )

  } catch (error) {
    console.error('Edge function error:', error)
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { 
        status: 500, 
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    )
  }
})